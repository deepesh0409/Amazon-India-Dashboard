export type TimeRange = 'FY24' | 'Q4-24' | 'Q3-24' | 'Q2-24' | 'Q1-24' | 'H2-24' | 'H1-24';

export type CurrencyMode = 'crores' | 'lakhs' | 'standard';

export interface MonthlyTrend {
  month: string;
  monthShort: string;
  sales: number; // in INR
  profit: number; // in INR
  orders: number;
  unitsSold: number;
  returnRate: number; // percentage
  cancellationRate: number; // percentage
}

export interface CategoryData {
  id: string;
  name: string;
  sales: number;
  profit: number;
  unitsSold: number;
  orders: number;
  profitMargin: number;
  returnRate: number;
  cancellationRate: number;
  color: string;
  subCategories: string[];
}

export interface ProductItem {
  id: string;
  sku: string;
  name: string;
  category: string;
  sales: number;
  profit: number;
  profitMargin: number;
  unitsSold: number;
  avgSellingPrice: number;
  returnRate: number;
  stockStatus: 'In Stock' | 'Low Stock' | 'Reorder';
  fulfillmentType: 'FBA' | 'Easy Ship' | 'Seller Fulfilled';
  rating: number;
}

export interface OrderStatusMetrics {
  totalOrders: number;
  deliveredOrders: number;
  shippedOrders: number;
  returnedOrders: number;
  cancelledOrders: number;
  returnRate: number;
  cancellationRate: number;
  deliveredRate: number;
  estimatedReturnRevenueLoss: number;
  estimatedCancellationRevenueLoss: number;
  reverseLogisticsCost: number;
}

export interface PaymentMethodData {
  method: string;
  label: string;
  sales: number;
  profit: number;
  orders: number;
  profitMargin: number;
  rtoRate: number; // Return To Origin rate (notably higher in COD)
  sharePercentage: number;
  iconName: string;
}

export interface FulfillmentMethodData {
  method: 'FBA' | 'Easy Ship' | 'Seller Fulfilled';
  name: string;
  description: string;
  sales: number;
  profit: number;
  orders: number;
  unitsSold: number;
  profitMargin: number;
  avgDeliveryDays: number;
  onTimeDeliveryRate: number;
  sharePercentage: number;
}

export interface StatePerformance {
  state: string;
  stateCode: string;
  region: 'North' | 'South' | 'West' | 'East' | 'Central';
  sales: number;
  profit: number;
  orders: number;
  unitsSold: number;
  profitMargin: number;
  returnRate: number;
  topCategory: string;
}

export interface ExecutiveInsight {
  type: 'positive' | 'warning' | 'info' | 'critical';
  title: string;
  description: string;
  metric: string;
  actionableStep?: string;
}
