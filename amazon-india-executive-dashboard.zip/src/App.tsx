import React, { useState } from 'react';
import {
  CurrencyMode,
  TimeRange,
} from './types/dashboard';
import { Header } from './components/Header';
import { ExecutiveSummaryBanner } from './components/ExecutiveSummaryBanner';
import { SalesProfitSection } from './components/SalesProfitSection';
import { CategoryProductSection } from './components/CategoryProductSection';
import { OrderStatusLossSection } from './components/OrderStatusLossSection';
import { PaymentFulfillmentGeoSection } from './components/PaymentFulfillmentGeoSection';
import { RaviManagementMemo } from './components/RaviManagementMemo';
import { PresentationMode } from './components/PresentationMode';
import {
  HelpCircle,
  FileSpreadsheet,
  Printer,
  Sparkles,
  ChevronUp,
  ShieldCheck,
  CheckCircle2,
} from 'lucide-react';
import { GLOSSARY } from './utils/formatters';

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>('all');
  const [currencyMode, setCurrencyMode] = useState<CurrencyMode>('crores');
  const [timeRange, setTimeRange] = useState<TimeRange>('FY24');
  const [isPresentationMode, setIsPresentationMode] = useState<boolean>(false);
  const [showGlossaryModal, setShowGlossaryModal] = useState<boolean>(false);

  const handlePrint = () => {
    window.print();
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col">
      {/* App Header with branding, navigation & controls */}
      <Header
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        currencyMode={currencyMode}
        setCurrencyMode={setCurrencyMode}
        timeRange={timeRange}
        setTimeRange={setTimeRange}
        isPresentationMode={isPresentationMode}
        setIsPresentationMode={setIsPresentationMode}
        onPrint={handlePrint}
      />

      {/* Presentation Mode Overlay (Slides 1 to 5) */}
      {isPresentationMode && (
        <PresentationMode
          onClose={() => setIsPresentationMode(false)}
          currencyMode={currencyMode}
          timeRange={timeRange}
          onPrint={handlePrint}
        />
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-10">
        {/* Executive Summary Banner (Always visible or in Master View) */}
        {currentTab !== 'memo' && (
          <ExecutiveSummaryBanner
            currencyMode={currencyMode}
            onNavigateToTab={(tab) => setCurrentTab(tab)}
          />
        )}

        {/* Tab 1: All-in-One Master Dashboard */}
        {currentTab === 'all' && (
          <div className="space-y-12">
            {/* Section 1: Slide 2 */}
            <div id="section-sales">
              <SalesProfitSection currencyMode={currencyMode} timeRange={timeRange} />
            </div>

            <div className="h-px bg-slate-200"></div>

            {/* Section 2: Slide 3 */}
            <div id="section-category">
              <CategoryProductSection currencyMode={currencyMode} />
            </div>

            <div className="h-px bg-slate-200"></div>

            {/* Section 3: Slide 4 */}
            <div id="section-orders">
              <OrderStatusLossSection currencyMode={currencyMode} />
            </div>

            <div className="h-px bg-slate-200"></div>

            {/* Section 4: Slide 5 */}
            <div id="section-channels">
              <PaymentFulfillmentGeoSection currencyMode={currencyMode} />
            </div>

            <div className="h-px bg-slate-200"></div>

            {/* Section 5: Manoj's Memo & Ravi Sign-off */}
            <div id="section-memo">
              <RaviManagementMemo currencyMode={currencyMode} onPrint={handlePrint} />
            </div>
          </div>
        )}

        {/* Tab 2: Sales & Profit Deep Dive (Slide 2) */}
        {currentTab === 'sales' && (
          <SalesProfitSection currencyMode={currencyMode} timeRange={timeRange} />
        )}

        {/* Tab 3: Category & Product Performance (Slide 3) */}
        {currentTab === 'category' && (
          <CategoryProductSection currencyMode={currencyMode} />
        )}

        {/* Tab 4: Order Status & Revenue Loss (Slide 4) */}
        {currentTab === 'orders' && (
          <OrderStatusLossSection currencyMode={currencyMode} />
        )}

        {/* Tab 5: Payment, Fulfillment & Geography (Slide 5) */}
        {currentTab === 'channels' && (
          <PaymentFulfillmentGeoSection currencyMode={currencyMode} />
        )}

        {/* Tab 6: Ravi Management Memo */}
        {currentTab === 'memo' && (
          <RaviManagementMemo currencyMode={currencyMode} onPrint={handlePrint} />
        )}
      </main>

      {/* Non-Technical Glossary Drawer / Modal for Ravi */}
      {showGlossaryModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-100 text-amber-800">
                  <HelpCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-lg">
                    Non-Technical Executive Glossary
                  </h3>
                  <p className="text-xs text-slate-500">
                    Plain-English explanations designed specifically for Ravi
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowGlossaryModal(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold p-1 rounded-lg"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-4 text-xs font-sans">
              {Object.entries(GLOSSARY).map(([key, item]) => (
                <div key={key} className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="font-bold text-slate-900 text-sm">{item.title}</div>
                  <p className="text-slate-600 mt-1 leading-relaxed">{item.explanation}</p>
                  <div className="mt-2 text-indigo-700 bg-indigo-50 p-2 rounded-xl border border-indigo-100">
                    <strong className="text-indigo-900">Why it matters to Ravi:</strong>{' '}
                    {item.whyItMatters}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setShowGlossaryModal(false)}
                className="px-5 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800"
              >
                Back to Dashboard
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Corporate Executive Footer */}
      <footer className="mt-16 bg-white border-t border-slate-200 text-slate-600 text-xs py-8 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="h-7 w-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-black text-xs">
              SQ
            </div>
            <div>
              <p className="font-bold text-slate-900">
                SAPPHiRE IQ Analytics • Amazon India Marketplace Division
              </p>
              <p className="text-[11px] text-slate-500">
                Prepared by Manoj for General Manager Ravi • Non-Technical Management Report
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs">
            <button
              onClick={() => setShowGlossaryModal(true)}
              className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Executive Glossary</span>
            </button>
            <span>•</span>
            <button
              onClick={() => setIsPresentationMode(true)}
              className="hover:text-slate-900 font-medium"
            >
              Slides Mode (PDF Matching)
            </button>
            <span>•</span>
            <button
              onClick={scrollToTop}
              className="hover:text-slate-900 flex items-center gap-1 font-medium"
            >
              <ChevronUp className="w-3.5 h-3.5" />
              <span>Back to Top</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
