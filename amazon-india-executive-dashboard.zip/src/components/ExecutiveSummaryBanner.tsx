import React, { useState } from 'react';
import {
  Sparkles,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  ChevronDown,
  Info,
  ShieldAlert,
  ArrowRight,
} from 'lucide-react';
import { EXECUTIVE_INSIGHTS } from '../data/mockData';
import { formatINR } from '../utils/formatters';
import { CurrencyMode } from '../types/dashboard';

interface ExecutiveSummaryBannerProps {
  currencyMode: CurrencyMode;
  onNavigateToTab: (tab: string) => void;
}

export const ExecutiveSummaryBanner: React.FC<ExecutiveSummaryBannerProps> = ({
  currencyMode,
  onNavigateToTab,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-5 sm:p-6 text-white shadow-xl border border-indigo-900/40 relative overflow-hidden mb-8">
      {/* Background glow effects */}
      <div className="absolute -right-16 -top-16 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute right-1/3 -bottom-16 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="relative z-10">
        {/* Top executive metadata badge */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 font-bold text-xs border border-amber-400/30">
              <Sparkles className="w-3.5 h-3.5" />
              Executive Briefing for Ravi
            </span>
            <span className="text-xs text-slate-300 hidden sm:inline">
              Submission by: Manoj | Amazon India Marketplace
            </span>
          </div>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-xs font-semibold text-indigo-300 hover:text-white flex items-center gap-1 transition-colors px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10"
          >
            <span>{isExpanded ? 'Hide Detailed Takeaways' : 'View All 4 Strategic Takeaways'}</span>
            {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Core objective callout & Verdict */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-8">
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white mb-2">
              Business Health: <span className="text-emerald-400">Strong Growth</span> with High Margin Resilience (19.85%)
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed max-w-3xl">
              Amazon India operations generated <strong className="text-white">{formatINR(480000000, currencyMode)}</strong> in gross revenue with <strong className="text-emerald-300">{formatINR(95280000, currencyMode)}</strong> net contribution profit across 2.88 Lakh customer orders. The primary operational priority for next quarter is addressing the <strong>17.8% COD return rate</strong> in Fashion.
            </p>
          </div>

          {/* Quick Score card for Ravi */}
          <div className="lg:col-span-4 bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10 flex items-center justify-between">
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-300">
                Operational Efficiency Score
              </div>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-extrabold text-white">88</span>
                <span className="text-xs font-medium text-slate-400">/ 100</span>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full">
                  Healthy
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                98.7% FBA On-Time Delivery | 44% UPI Share
              </div>
            </div>

            <button
              onClick={() => onNavigateToTab('memo')}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1 shadow-md transition-all hover:scale-105"
            >
              <span>Read Memo</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Expandable Strategic Insights for Ravi */}
        {isExpanded && (
          <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in duration-300">
            {EXECUTIVE_INSIGHTS.map((insight, idx) => (
              <div
                key={idx}
                className="bg-white/5 rounded-2xl p-4 border border-white/10 hover:bg-white/10 transition-colors"
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    {insight.type === 'positive' && (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    )}
                    {insight.type === 'critical' && (
                      <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                    )}
                    {insight.type === 'warning' && (
                      <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
                    )}
                    <h4 className="text-sm font-bold text-white">{insight.title}</h4>
                  </div>
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-white/10 text-amber-300 font-semibold shrink-0">
                    {insight.metric}
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed mb-3">
                  {insight.description}
                </p>
                {insight.actionableStep && (
                  <div className="text-[11px] bg-slate-900/60 p-2.5 rounded-xl border border-white/5 text-amber-200 flex items-start gap-1.5">
                    <span className="font-bold text-amber-400 shrink-0">Action for Ravi:</span>
                    <span>{insight.actionableStep}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
