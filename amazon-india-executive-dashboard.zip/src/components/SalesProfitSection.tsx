import React, { useState } from 'react';
import {
  TrendingUp,
  DollarSign,
  ShoppingCart,
  Package,
  CreditCard,
  Percent,
  Calendar,
  Sparkles,
  ArrowUpRight,
  HelpCircle,
  BarChart2,
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  Area,
} from 'recharts';
import { MONTHLY_DATA } from '../data/mockData';
import { CurrencyMode, TimeRange } from '../types/dashboard';
import { formatINR, formatNumber, formatPercent } from '../utils/formatters';
import { MetricCard } from './MetricCard';

interface SalesProfitSectionProps {
  currencyMode: CurrencyMode;
  timeRange: TimeRange;
}

export const SalesProfitSection: React.FC<SalesProfitSectionProps> = ({
  currencyMode,
  timeRange,
}) => {
  const [chartMetric, setChartMetric] = useState<'both' | 'sales' | 'profit'>('both');

  // Filter or aggregate data based on selected time range
  const filteredData = React.useMemo(() => {
    if (timeRange === 'Q1-24') return MONTHLY_DATA.slice(3, 6); // Apr - Jun
    if (timeRange === 'Q2-24') return MONTHLY_DATA.slice(6, 9); // Jul - Sep
    if (timeRange === 'Q3-24') return MONTHLY_DATA.slice(9, 12); // Oct - Dec
    if (timeRange === 'Q4-24') return MONTHLY_DATA.slice(0, 3); // Jan - Mar
    if (timeRange === 'H1-24') return MONTHLY_DATA.slice(3, 9);
    if (timeRange === 'H2-24') return [...MONTHLY_DATA.slice(9, 12), ...MONTHLY_DATA.slice(0, 3)];
    return MONTHLY_DATA;
  }, [timeRange]);

  const totalSales = filteredData.reduce((acc, curr) => acc + curr.sales, 0);
  const totalProfit = filteredData.reduce((acc, curr) => acc + curr.profit, 0);
  const totalOrders = filteredData.reduce((acc, curr) => acc + curr.orders, 0);
  const totalUnits = filteredData.reduce((acc, curr) => acc + curr.unitsSold, 0);
  const avgOrderValue = totalOrders > 0 ? totalSales / totalOrders : 0;
  const profitMargin = totalSales > 0 ? (totalProfit / totalSales) * 100 : 0;

  // Chart data formatting
  const chartData = filteredData.map((d) => ({
    name: d.monthShort,
    fullMonth: d.month,
    sales: d.sales,
    profit: d.profit,
    salesCr: d.sales / 10000000,
    profitCr: d.profit / 10000000,
    profitMargin: ((d.profit / d.sales) * 100).toFixed(1),
    orders: d.orders,
    unitsSold: d.unitsSold,
  }));

  // Custom Recharts Tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 text-white p-3.5 rounded-xl shadow-xl border border-slate-800 text-xs min-w-[200px]">
          <p className="font-bold text-amber-400 text-sm mb-2">{data.fullMonth}</p>
          <div className="space-y-1.5 font-sans">
            <div className="flex justify-between items-center text-slate-300">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-blue-500 inline-block"></span>
                Sales:
              </span>
              <span className="font-bold text-white font-mono">{formatINR(data.sales, currencyMode)}</span>
            </div>
            <div className="flex justify-between items-center text-slate-300">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 inline-block"></span>
                Net Profit:
              </span>
              <span className="font-bold text-emerald-400 font-mono">{formatINR(data.profit, currencyMode)}</span>
            </div>
            <div className="flex justify-between items-center text-slate-300">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-amber-400 inline-block"></span>
                Profit Margin:
              </span>
              <span className="font-bold text-amber-300 font-mono">{data.profitMargin}%</span>
            </div>
            <div className="pt-1.5 border-t border-slate-800 flex justify-between text-slate-400 text-[11px]">
              <span>Orders: {formatNumber(data.orders)}</span>
              <span>Units: {formatNumber(data.unitsSold)}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <section className="space-y-6">
      {/* Slide 2 Header Banner */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 text-white rounded-2xl p-5 sm:p-6 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white font-bold text-xs uppercase tracking-wider backdrop-blur-xs">
              Slide 2 of 5
            </span>
            <span className="text-blue-100 text-xs font-semibold">AMAZON INDIA DASHBOARD</span>
          </div>
          <span className="text-xs bg-blue-500/30 px-3 py-1 rounded-full border border-blue-300/30 font-medium">
            Executive Pillar: Financial Vitality
          </span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          1) Overall Sales & Profit Performance
        </h2>

        <div className="mt-2 text-blue-100 text-sm font-medium flex items-center gap-2">
          <span className="font-bold text-amber-300">Business Question:</span>
          <span className="underline decoration-blue-300 decoration-1 underline-offset-4">
            How is the business performing overall?
          </span>
        </div>
      </div>

      {/* The 6 Core KPIs required by Slide 2 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* 1. Total Sales */}
        <MetricCard
          title="Total Sales"
          value={formatINR(totalSales, currencyMode)}
          subValue="Gross Merchandise Value"
          change={{ value: '+24.2%', isPositive: true }}
          variant="primary"
          glossaryKey="Total Sales"
          icon={<DollarSign className="w-4 h-4" />}
        />

        {/* 2. Total Profit */}
        <MetricCard
          title="Total Profit"
          value={formatINR(totalProfit, currencyMode)}
          subValue="Net contribution margin"
          change={{ value: '+26.8%', isPositive: true }}
          variant="success"
          glossaryKey="Total Profit"
          icon={<TrendingUp className="w-4 h-4" />}
        />

        {/* 3. Total Orders */}
        <MetricCard
          title="Total Orders"
          value={formatNumber(totalOrders)}
          subValue="Delivered & active orders"
          change={{ value: '+18.5%', isPositive: true }}
          variant="default"
          icon={<ShoppingCart className="w-4 h-4" />}
        />

        {/* 4. Total Units Sold */}
        <MetricCard
          title="Total Units Sold"
          value={formatNumber(totalUnits)}
          subValue="~1.34 units per order"
          change={{ value: '+21.0%', isPositive: true }}
          variant="purple"
          icon={<Package className="w-4 h-4" />}
        />

        {/* 5. Average Order Value (AOV) */}
        <MetricCard
          title="Average Order Value"
          value={formatINR(avgOrderValue, 'standard', 0)}
          subValue="Avg customer basket"
          change={{ value: '+4.8%', isPositive: true }}
          variant="warning"
          glossaryKey="Average Order Value"
          icon={<CreditCard className="w-4 h-4" />}
        />

        {/* 6. Profit Margin % */}
        <MetricCard
          title="Profit Margin %"
          value={formatPercent(profitMargin, 1)}
          subValue="Net margin on revenue"
          change={{ value: '+0.4%', isPositive: true }}
          variant="success"
          glossaryKey="Profit Margin %"
          icon={<Percent className="w-4 h-4" />}
        />
      </div>

      {/* Monthly Sales & Profit Trend Chart (Slide 2 Requirement) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-indigo-600" />
              <h3 className="text-base font-bold text-slate-900">
                Monthly Sales & Profit Trend
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Tracking monthly revenue, net profit, and profit margin percentage trajectory
            </p>
          </div>

          {/* Metric display filter buttons */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs font-semibold text-slate-600">
            <button
              onClick={() => setChartMetric('both')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                chartMetric === 'both' ? 'bg-white text-indigo-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              Sales & Profit
            </button>
            <button
              onClick={() => setChartMetric('sales')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                chartMetric === 'sales' ? 'bg-white text-blue-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              Sales Only
            </button>
            <button
              onClick={() => setChartMetric('profit')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${
                chartMetric === 'profit' ? 'bg-white text-emerald-700 shadow-xs' : 'hover:text-slate-900'
              }`}
            >
              Profit Only
            </button>
          </div>
        </div>

        {/* Chart area */}
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={chartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis
                dataKey="name"
                tick={{ fill: '#64748b', fontSize: 11, fontWeight: 500 }}
                tickLine={false}
                axisLine={{ stroke: '#e2e8f0' }}
              />
              <YAxis
                yAxisId="left"
                tick={{ fill: '#64748b', fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => `₹${(val / 10000000).toFixed(1)}Cr`}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                domain={[0, 30]}
                tick={{ fill: '#d97706', fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                tickFormatter={(val) => `${val}%`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="top"
                align="right"
                wrapperStyle={{ paddingBottom: 16, fontSize: 12 }}
              />

              {(chartMetric === 'both' || chartMetric === 'sales') && (
                <Bar
                  yAxisId="left"
                  dataKey="sales"
                  name="Total Sales (₹)"
                  fill="#3b82f6"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={40}
                />
              )}

              {(chartMetric === 'both' || chartMetric === 'profit') && (
                <Bar
                  yAxisId="left"
                  dataKey="profit"
                  name="Net Profit (₹)"
                  fill="#10b981"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={40}
                />
              )}

              <Line
                yAxisId="right"
                type="monotone"
                dataKey="profitMargin"
                name="Profit Margin %"
                stroke="#f59e0b"
                strokeWidth={3}
                dot={{ r: 4, fill: '#f59e0b', strokeWidth: 2, stroke: '#ffffff' }}
                activeDot={{ r: 6 }}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        {/* Legend notes */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-2">
          <div className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-xs bg-blue-500"></span>
              Sales peak in Oct (Great Indian Festival: ₹6.89 Cr)
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-xs bg-emerald-500"></span>
              Profit peak in Oct (₹1.38 Cr) & Nov (₹1.13 Cr)
            </span>
          </div>
          <span className="text-slate-400">Values in INR (Crores / Lakhs)</span>
        </div>
      </div>

      {/* Slide 2: Expected Insight Box */}
      <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-5 text-amber-900 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-amber-100 text-amber-800 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-sm text-amber-950 uppercase tracking-wide">
                Expected Insight for Ravi:
              </h4>
              <span className="text-[11px] bg-amber-200/80 text-amber-900 px-2 py-0.5 rounded font-semibold">
                Sales & Profit Trajectory
              </span>
            </div>
            <p className="text-xs sm:text-sm text-amber-900 leading-relaxed">
              <strong>Manoj's Executive Assessment:</strong> Sales and profitability are <strong>consistently improving over time</strong>. The business experienced steady monthly performance from Jan–Sep (averaging ₹35 Cr/month), followed by a massive surge during Q3 festive season (Oct–Nov combined GMV ₹12.53 Cr, delivering ₹2.51 Cr in profit). Margin has stayed locked between <strong>19.0% and 20.0%</strong>, proving that festive discounts did not degrade unit profitability.
            </p>
            <div className="pt-2 flex flex-wrap gap-4 text-xs font-medium text-amber-800">
              <span>• Festive Surge: <strong>+82%</strong> revenue increase in Oct vs Feb base</span>
              <span>• Margin Stability: Maintained <strong>19.85%</strong> despite ad spend</span>
              <span>• Healthy Basket: AOV expanded to <strong>₹1,664</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
