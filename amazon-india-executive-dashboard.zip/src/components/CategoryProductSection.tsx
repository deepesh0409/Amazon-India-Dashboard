import React, { useState, useMemo } from 'react';
import {
  Layers,
  Sparkles,
  Search,
  Filter,
  ArrowUpDown,
  AlertTriangle,
  CheckCircle,
  PackageCheck,
  TrendingUp,
  Tag,
  Star,
  ExternalLink,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import { CATEGORIES_DATA, TOP_PRODUCTS } from '../data/mockData';
import { CurrencyMode, ProductItem } from '../types/dashboard';
import { formatINR, formatNumber, formatPercent } from '../utils/formatters';

interface CategoryProductSectionProps {
  currencyMode: CurrencyMode;
}

export const CategoryProductSection: React.FC<CategoryProductSectionProps> = ({
  currencyMode,
}) => {
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortField, setSortField] = useState<keyof ProductItem>('sales');
  const [sortAsc, setSortAsc] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<'sales' | 'profit' | 'units'>('sales');

  // Filtered and sorted products
  const filteredProducts = useMemo(() => {
    return TOP_PRODUCTS.filter((product) => {
      const matchesCategory =
        selectedCategoryFilter === 'all' || product.category === selectedCategoryFilter;
      const matchesSearch =
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    }).sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortAsc ? aVal - bVal : bVal - aVal;
      }
      return sortAsc
        ? String(aVal).localeCompare(String(bVal))
        : String(bVal).localeCompare(String(aVal));
    });
  }, [selectedCategoryFilter, searchQuery, sortField, sortAsc]);

  const handleSort = (field: keyof ProductItem) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  // Pie chart data for Category share
  const categoryPieData = CATEGORIES_DATA.map((cat) => ({
    name: cat.name,
    value: cat.sales,
    profit: cat.profit,
    units: cat.unitsSold,
    color: cat.color,
  }));

  // Bar chart data
  const categoryBarData = CATEGORIES_DATA.map((cat) => ({
    name: cat.name.split(' ')[0], // short name
    fullName: cat.name,
    Sales: cat.sales / 10000000,
    Profit: cat.profit / 10000000,
    Units: cat.unitsSold / 1000,
    Margin: cat.profitMargin,
    salesRaw: cat.sales,
    profitRaw: cat.profit,
    unitsRaw: cat.unitsSold,
    returnRate: cat.returnRate,
  }));

  return (
    <section className="space-y-6">
      {/* Slide 3 Header Banner */}
      <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-purple-800 text-white rounded-2xl p-5 sm:p-6 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white font-bold text-xs uppercase tracking-wider backdrop-blur-xs">
              Slide 3 of 5
            </span>
            <span className="text-purple-200 text-xs font-semibold">AMAZON INDIA DASHBOARD</span>
          </div>
          <span className="text-xs bg-purple-500/30 px-3 py-1 rounded-full border border-purple-300/30 font-medium">
            Executive Pillar: Catalog & Merchandising
          </span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          2) Category & Product Performance
        </h2>

        <div className="mt-2 text-purple-100 text-sm font-medium flex items-center gap-2">
          <span className="font-bold text-amber-300">Business Question:</span>
          <span className="underline decoration-purple-300 decoration-1 underline-offset-4">
            Which products and categories are driving the business?
          </span>
        </div>
      </div>

      {/* Slide 3 Requirements: Category-wise Sales, Profit, Units Sold */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Category Comparison Chart */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Layers className="w-5 h-5 text-purple-600" />
                Category-wise Sales, Profit & Units Sold
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Comparing revenue, bottom-line profit, and order volumes across 6 key Amazon departments
              </p>
            </div>

            {/* Toggle metric */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold text-slate-600">
              <button
                onClick={() => setViewMode('sales')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  viewMode === 'sales' ? 'bg-white text-blue-700 shadow-xs' : 'hover:text-slate-900'
                }`}
              >
                Sales & Profit (₹ Cr)
              </button>
              <button
                onClick={() => setViewMode('units')}
                className={`px-3 py-1 rounded-lg transition-colors ${
                  viewMode === 'units' ? 'bg-white text-purple-700 shadow-xs' : 'hover:text-slate-900'
                }`}
              >
                Units Sold (Thousands)
              </button>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryBarData} margin={{ top: 10, right: 10, left: 0, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis
                  dataKey="name"
                  tick={{ fill: '#475569', fontSize: 11, fontWeight: 600 }}
                  tickLine={false}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis
                  tick={{ fill: '#64748b', fontSize: 11 }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) =>
                    viewMode === 'sales' ? `₹${val}Cr` : `${val}k`
                  }
                />
                <Tooltip
                  formatter={(val: any, name: any, item: any) => {
                    if (name === 'Sales (₹ Cr)') {
                      return [formatINR(item.payload.salesRaw, currencyMode), 'Total Sales'];
                    }
                    if (name === 'Profit (₹ Cr)') {
                      return [formatINR(item.payload.profitRaw, currencyMode), 'Net Profit'];
                    }
                    if (name === 'Units (k)') {
                      return [formatNumber(item.payload.unitsRaw), 'Units Sold'];
                    }
                    return [val, name];
                  }}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: 10 }} />

                {viewMode === 'sales' ? (
                  <>
                    <Bar
                      dataKey="Sales"
                      name="Sales (₹ Cr)"
                      fill="#3b82f6"
                      radius={[6, 6, 0, 0]}
                      maxBarSize={32}
                    />
                    <Bar
                      dataKey="Profit"
                      name="Profit (₹ Cr)"
                      fill="#10b981"
                      radius={[6, 6, 0, 0]}
                      maxBarSize={32}
                    />
                  </>
                ) : (
                  <Bar
                    dataKey="Units"
                    name="Units (k)"
                    fill="#8b5cf6"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={40}
                  />
                )}
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right Column: Category Distribution & Insights */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h4 className="text-sm font-bold text-slate-900 mb-1">
              Category Share Breakdown
            </h4>
            <p className="text-xs text-slate-500 mb-4">
              Electronics (38%) and Fashion (23%) represent 61% of total marketplace turnover
            </p>

            <div className="space-y-3">
              {CATEGORIES_DATA.map((cat) => {
                const share = ((cat.sales / 480000000) * 100).toFixed(1);
                return (
                  <div key={cat.id} className="text-xs">
                    <div className="flex items-center justify-between font-medium mb-1">
                      <span className="flex items-center gap-1.5 text-slate-800">
                        <span
                          className="w-2.5 h-2.5 rounded-full inline-block"
                          style={{ backgroundColor: cat.color }}
                        ></span>
                        {cat.name}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-slate-500 font-mono">{share}%</span>
                        <span className="font-bold text-slate-900 font-mono">
                          {formatINR(cat.sales, currencyMode)}
                        </span>
                      </div>
                    </div>
                    {/* Progress bar */}
                    <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${share}%`,
                          backgroundColor: cat.color,
                        }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-5 p-3 rounded-xl bg-purple-50 border border-purple-100 text-purple-900 text-xs">
            <span className="font-bold">Key Category Takeaway:</span> Mobile Accessories has the highest profit margin at <strong>26.0%</strong>, whereas Apparel has the highest return rate at <strong>14.6%</strong>.
          </div>
        </div>
      </div>

      {/* Top 10 Products by Sales Table (Slide 3 Requirement) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center text-xs font-bold">
                10
              </span>
              <h3 className="text-base font-bold text-slate-900">
                Top 10 Products by Sales (Hero Catalog)
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Individual SKU performance, profitability, stock levels, and return vulnerability
            </p>
          </div>

          {/* Search & Category Filter Controls */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search SKU or product..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/20"
              />
            </div>

            <select
              value={selectedCategoryFilter}
              onChange={(e) => setSelectedCategoryFilter(e.target.value)}
              className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-purple-500/20"
            >
              <option value="all">All Categories</option>
              {CATEGORIES_DATA.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Responsive Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <th className="p-3 w-10 text-center">#</th>
                <th
                  onClick={() => handleSort('name')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>Product & SKU</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="p-3">Category</th>
                <th
                  onClick={() => handleSort('sales')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Total Sales</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('profit')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Net Profit</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('profitMargin')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Margin %</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('unitsSold')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Units</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('returnRate')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-center"
                >
                  <div className="flex items-center justify-center gap-1">
                    <span>Return Rate</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="p-3 text-center">Fulfillment</th>
                <th className="p-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {filteredProducts.map((p, index) => {
                const isHighReturn = p.returnRate > 10;
                return (
                  <tr
                    key={p.id}
                    className={`hover:bg-slate-50/80 transition-colors ${
                      isHighReturn ? 'bg-rose-50/30' : ''
                    }`}
                  >
                    <td className="p-3 text-center font-bold text-slate-400 font-mono">
                      {index + 1}
                    </td>
                    <td className="p-3 max-w-xs">
                      <div className="font-semibold text-slate-900 truncate" title={p.name}>
                        {p.name}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {p.sku} • ₹{p.avgSellingPrice} ASP
                      </div>
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-slate-100 text-slate-700">
                        {p.category}
                      </span>
                    </td>
                    <td className="p-3 text-right font-bold text-slate-900 font-mono whitespace-nowrap">
                      {formatINR(p.sales, currencyMode)}
                    </td>
                    <td className="p-3 text-right font-bold text-emerald-600 font-mono whitespace-nowrap">
                      {formatINR(p.profit, currencyMode)}
                    </td>
                    <td className="p-3 text-right font-semibold text-slate-800 font-mono">
                      <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                        {p.profitMargin}%
                      </span>
                    </td>
                    <td className="p-3 text-right font-mono text-slate-600">
                      {formatNumber(p.unitsSold)}
                    </td>
                    <td className="p-3 text-center">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full font-semibold font-mono text-[11px] ${
                          isHighReturn
                            ? 'bg-rose-100 text-rose-800 border border-rose-200'
                            : 'bg-emerald-50 text-emerald-700'
                        }`}
                      >
                        {p.returnRate}%
                      </span>
                    </td>
                    <td className="p-3 text-center whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                          p.fulfillmentType === 'FBA'
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : p.fulfillmentType === 'Easy Ship'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {p.fulfillmentType}
                      </span>
                    </td>
                    <td className="p-3 text-center whitespace-nowrap">
                      {p.stockStatus === 'In Stock' && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                          <CheckCircle className="w-3 h-3 text-emerald-500" />
                          In Stock
                        </span>
                      )}
                      {p.stockStatus === 'Low Stock' && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
                          <AlertTriangle className="w-3 h-3 text-amber-500" />
                          Low Stock
                        </span>
                      )}
                      {p.stockStatus === 'Reorder' && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full">
                          <AlertTriangle className="w-3 h-3 text-rose-500" />
                          Reorder
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Slide 3: Expected Insight Box */}
      <div className="bg-purple-50/70 border border-purple-200 rounded-2xl p-5 text-purple-950 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-purple-100 text-purple-800 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-sm text-purple-950 uppercase tracking-wide">
                Expected Insight for Ravi:
              </h4>
              <span className="text-[11px] bg-purple-200 text-purple-900 px-2 py-0.5 rounded font-semibold">
                Catalog & Merchandising Strategy
              </span>
            </div>
            <p className="text-xs sm:text-sm text-purple-900 leading-relaxed">
              <strong>Manoj's Executive Assessment:</strong> Electronics is the volume and top-line powerhouse (generating ₹18.45 Cr with ₹3.69 Cr profit), driven by high-velocity audio and smartwatches. However, <strong>two products demand Ravi's immediate intervention</strong>:
            </p>
            <div className="pt-2 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-medium text-purple-900">
              <div className="bg-white/80 p-3 rounded-xl border border-purple-200">
                <span className="font-bold text-emerald-700">★ High Performer: boAt Airdopes 141</span>
                <p className="text-[11px] text-slate-600 mt-1">
                  Generated ₹2.45 Cr sales at 22% margin with low 4.8% return rate via FBA. Recommend increasing safety stock before upcoming Prime Day.
                </p>
              </div>
              <div className="bg-white/80 p-3 rounded-xl border border-rose-200">
                <span className="font-bold text-rose-700">⚠ Needs Attention: Dennis Lingo Shirt & Biba Kurta</span>
                <p className="text-[11px] text-slate-600 mt-1">
                  Suffering high return rates (16.4% and 15.2%) due to size discrepancies, eroding net margins down to 15%. Recommend standardizing size charts with 3D fit guide.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
