import React, { useState } from 'react';
import {
  FileText,
  Send,
  CheckCircle2,
  Clock,
  Printer,
  Sparkles,
  Download,
  ShieldCheck,
  AlertTriangle,
  UserCheck,
  Check,
  Edit3,
} from 'lucide-react';
import { MANOJ_MEMO } from '../data/mockData';
import { CurrencyMode } from '../types/dashboard';
import { formatINR } from '../utils/formatters';

interface RaviManagementMemoProps {
  currencyMode: CurrencyMode;
  onPrint: () => void;
}

export const RaviManagementMemo: React.FC<RaviManagementMemoProps> = ({
  currencyMode,
  onPrint,
}) => {
  const [memoText, setMemoText] = useState(MANOJ_MEMO.executiveSummary);
  const [isEditing, setIsEditing] = useState(false);
  const [approvalStatus, setApprovalStatus] = useState<Record<string, 'approved' | 'review' | 'deferred'>>({
    action1: 'approved',
    action2: 'review',
    action3: 'approved',
  });

  const toggleApproval = (id: string) => {
    setApprovalStatus((prev) => {
      const nextState =
        prev[id] === 'approved'
          ? 'review'
          : prev[id] === 'review'
          ? 'deferred'
          : 'approved';
      return { ...prev, [id]: nextState };
    });
  };

  return (
    <section className="space-y-6 max-w-5xl mx-auto">
      {/* Memo Top Header */}
      <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white rounded-2xl p-6 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white font-bold text-xs uppercase tracking-wider backdrop-blur-xs">
              Management Briefing
            </span>
            <span className="text-amber-100 text-xs font-semibold">SAPPHIRE IQ OPERATIONS</span>
          </div>
          <span className="text-xs bg-amber-500/30 px-3 py-1 rounded-full border border-amber-300/30 font-medium">
            Confidential • Internal Executive Review
          </span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          Executive Memo: Manoj to Ravi
        </h2>
        <p className="mt-1 text-amber-100 text-sm">
          Formal submission of Amazon India FY24 operational performance and strategic recommendations
        </p>
      </div>

      {/* Corporate Memo Paper */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-6 sm:p-10 relative overflow-hidden">
        {/* Memo Header Grid */}
        <div className="border-b-2 border-slate-900/10 pb-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="w-16 font-bold uppercase tracking-wider text-slate-500">TO:</span>
                <span className="font-bold text-slate-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  {MANOJ_MEMO.to}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-16 font-bold uppercase tracking-wider text-slate-500">FROM:</span>
                <span className="font-semibold text-slate-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  {MANOJ_MEMO.from}
                </span>
              </div>
            </div>

            <div className="space-y-1.5 md:text-right">
              <div className="flex md:justify-end items-center gap-2">
                <span className="font-bold uppercase tracking-wider text-slate-500">DATE:</span>
                <span className="font-medium text-slate-700">{MANOJ_MEMO.date}</span>
              </div>
              <div className="flex md:justify-end items-center gap-2">
                <span className="font-bold uppercase tracking-wider text-slate-500">STATUS:</span>
                <span className="inline-flex items-center gap-1 font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {MANOJ_MEMO.status}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center gap-2 text-xs">
            <span className="font-bold uppercase tracking-wider text-slate-500">SUBJECT:</span>
            <span className="font-bold text-slate-900 text-sm">{MANOJ_MEMO.subject}</span>
          </div>
        </div>

        {/* Memo Body with Edit Option */}
        <div className="relative mb-8">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Briefing Text
            </span>
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{isEditing ? 'Save Changes' : 'Customize Note'}</span>
            </button>
          </div>

          {isEditing ? (
            <textarea
              value={memoText}
              onChange={(e) => setMemoText(e.target.value)}
              rows={12}
              className="w-full p-4 border border-indigo-200 rounded-2xl bg-indigo-50/20 text-slate-800 text-xs sm:text-sm font-sans leading-relaxed focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          ) : (
            <div className="bg-slate-50/80 p-5 rounded-2xl border border-slate-200/80 text-xs sm:text-sm text-slate-800 leading-relaxed font-sans whitespace-pre-line">
              {memoText}
            </div>
          )}
        </div>

        {/* 3 Strategic Decisions for Ravi to Approve */}
        <div className="mt-8 pt-6 border-t border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Action Items for Ravi's Formal Sign-off
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Click any action badge to toggle approval status (Approved / Under Review / Deferred)
              </p>
            </div>
            <span className="text-xs text-slate-400 font-mono">3 Strategic Decisions</span>
          </div>

          <div className="space-y-3">
            {/* Action 1 */}
            <div className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-xs font-bold flex items-center justify-center">
                    1
                  </span>
                  <span className="font-bold text-slate-900 text-sm">
                    Pre-Deposit & OTP Verification for COD Apparel Orders
                  </span>
                </div>
                <p className="text-xs text-slate-600 pl-7">
                  Target: Reduce 17.8% COD return rate down to 10% in North Tier-2/3 pincodes, saving ~₹28 Lakhs in reverse courier penalties.
                </p>
              </div>

              <button
                onClick={() => toggleApproval('action1')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                  approvalStatus['action1'] === 'approved'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : approvalStatus['action1'] === 'review'
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-slate-100 text-slate-600 border border-slate-200'
                }`}
              >
                {approvalStatus['action1'] === 'approved' && <Check className="w-3.5 h-3.5" />}
                <span className="capitalize">{approvalStatus['action1']}</span>
              </button>
            </div>

            {/* Action 2 */}
            <div className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-xs font-bold flex items-center justify-center">
                    2
                  </span>
                  <span className="font-bold text-slate-900 text-sm">
                    Expand FBA Allocation for Top 20 Hero SKUs Prior to Prime Day
                  </span>
                </div>
                <p className="text-xs text-slate-600 pl-7">
                  Target: Ensure 100% in-stock rate at Bhiwandi & Attibele FCs for boAt, Noise, and Minimalist items to capture 21% net margins.
                </p>
              </div>

              <button
                onClick={() => toggleApproval('action2')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                  approvalStatus['action2'] === 'approved'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : approvalStatus['action2'] === 'review'
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-slate-100 text-slate-600 border border-slate-200'
                }`}
              >
                {approvalStatus['action2'] === 'approved' && <Check className="w-3.5 h-3.5" />}
                <span className="capitalize">{approvalStatus['action2']}</span>
              </button>
            </div>

            {/* Action 3 */}
            <div className="p-4 rounded-2xl border border-slate-200 bg-white hover:border-slate-300 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-900 text-white text-xs font-bold flex items-center justify-center">
                    3
                  </span>
                  <span className="font-bold text-slate-900 text-sm">
                    Incentivize Amazon Pay UPI at Checkout with 2% Instant Cashback
                  </span>
                </div>
                <p className="text-xs text-slate-600 pl-7">
                  Target: Increase UPI share from 44% to 55%, reducing cash collection disputes and delivery turnaround times.
                </p>
              </div>

              <button
                onClick={() => toggleApproval('action3')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                  approvalStatus['action3'] === 'approved'
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                    : approvalStatus['action3'] === 'review'
                    ? 'bg-amber-100 text-amber-800 border border-amber-300'
                    : 'bg-slate-100 text-slate-600 border border-slate-200'
                }`}
              >
                {approvalStatus['action3'] === 'approved' && <Check className="w-3.5 h-3.5" />}
                <span className="capitalize">{approvalStatus['action3']}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Action bar for Ravi */}
        <div className="mt-8 pt-6 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <UserCheck className="w-4 h-4 text-emerald-600" />
            <span>Digital signature verified: Manoj (Operations Lead, Sapphire IQ)</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onPrint}
              className="px-4 py-2 rounded-xl text-xs font-bold bg-slate-900 text-white hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Executive Memo</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
