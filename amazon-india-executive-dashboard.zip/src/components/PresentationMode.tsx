import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  X,
  Sparkles,
  BarChart3,
  Layers,
  RotateCcw,
  MapPin,
  FileText,
} from 'lucide-react';
import { CurrencyMode, TimeRange } from '../types/dashboard';
import { SalesProfitSection } from './SalesProfitSection';
import { CategoryProductSection } from './CategoryProductSection';
import { OrderStatusLossSection } from './OrderStatusLossSection';
import { PaymentFulfillmentGeoSection } from './PaymentFulfillmentGeoSection';
import { RaviManagementMemo } from './RaviManagementMemo';

interface PresentationModeProps {
  onClose: () => void;
  currencyMode: CurrencyMode;
  timeRange: TimeRange;
  onPrint: () => void;
}

export const PresentationMode: React.FC<PresentationModeProps> = ({
  onClose,
  currencyMode,
  timeRange,
  onPrint,
}) => {
  const [currentSlide, setCurrentSlide] = useState<number>(1);
  const totalSlides = 5;

  const nextSlide = () => {
    if (currentSlide < totalSlides) setCurrentSlide(currentSlide + 1);
  };

  const prevSlide = () => {
    if (currentSlide > 1) setCurrentSlide(currentSlide - 1);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white overflow-y-auto flex flex-col">
      {/* Top presentation toolbar */}
      <div className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-7 w-7 rounded-lg bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center text-white text-xs font-black">
            SQ
          </div>
          <div className="text-sm font-bold text-slate-200">
            SAPPHiRE IQ <span className="text-slate-400 font-normal">| Amazon India Executive Review</span>
          </div>
          <span className="hidden md:inline text-xs bg-slate-800 text-amber-400 px-2 py-0.5 rounded font-mono">
            Manoj ➔ Ravi
          </span>
        </div>

        {/* Slide Counter & Navigation Controls */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <button
              onClick={prevSlide}
              disabled={currentSlide === 1}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none transition-colors"
              title="Previous Slide (or Left Arrow)"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="text-xs font-mono font-bold px-3 py-1 bg-slate-800/80 rounded-lg">
              Slide {currentSlide} of {totalSlides}
            </div>
            <button
              onClick={nextSlide}
              disabled={currentSlide === totalSlides}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none transition-colors"
              title="Next Slide (or Right Arrow)"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <div className="h-4 w-px bg-slate-800"></div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-rose-900/40 hover:bg-rose-900/80 text-rose-300 transition-colors flex items-center gap-1 text-xs font-semibold px-2.5"
            title="Exit Presentation Mode"
          >
            <X className="w-4 h-4" />
            <span>Exit</span>
          </button>
        </div>
      </div>

      {/* Slide Content Area */}
      <div className="flex-1 p-6 md:p-10 max-w-6xl mx-auto w-full flex flex-col justify-center">
        {/* SLIDE 1: Title & Executive Scope */}
        {currentSlide === 1 && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 md:p-14 shadow-2xl relative overflow-hidden text-center md:text-left">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 border-b border-slate-800 pb-8">
              <div className="flex items-center gap-3 justify-center md:justify-start">
                <div className="h-12 w-12 rounded-2xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-lg">
                  <BarChart3 className="w-7 h-7 text-amber-300" />
                </div>
                <div>
                  <h1 className="text-2xl font-black tracking-tight text-white">
                    SAPPHiRE <span className="text-blue-400">IQ</span>
                  </h1>
                  <p className="text-xs uppercase tracking-widest text-slate-400 font-semibold">
                    Executive Analytics
                  </p>
                </div>
              </div>

              <div className="flex flex-col items-center md:items-end">
                <span className="text-3xl font-black tracking-tight text-white">amazon</span>
                <div className="w-24 h-1.5 bg-gradient-to-r from-amber-400 to-amber-500 rounded-full mt-0.5"></div>
              </div>
            </div>

            <div className="max-w-3xl mb-8">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20">
                Official Presentation Deck
              </span>
              <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-3 mb-4">
                Amazon India Dashboard
              </h2>
              <div className="space-y-4 text-slate-300 text-sm sm:text-base leading-relaxed">
                <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-800/40 text-indigo-200">
                  <strong className="text-white">Business Requirements & Objective:</strong>
                  <p className="mt-1 text-slate-300 text-sm">
                    The main objective of this project is to design a simple and easy-to-understand management dashboard for Manoj to submit to his manager, Ravi, who comes from a non-technical background.
                  </p>
                </div>
                <p className="text-slate-300 text-sm">
                  The dashboard provides a clear overview of Sales, Profit, Products, Orders, Customer Order Status, Payment, Fulfilment, and Geographic Performance in one place. It presents important business information through simple charts, graphs, and KPIs, enabling Ravi to quickly understand the overall business performance without requiring technical knowledge.
                </p>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4 text-xs text-slate-400">
                <span>Presenter: <strong>Manoj</strong> (Operations Lead)</span>
                <span>•</span>
                <span>Reviewer: <strong>Ravi</strong> (General Manager)</span>
              </div>

              <button
                onClick={nextSlide}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-6 py-2.5 rounded-xl text-sm flex items-center gap-2 transition-all shadow-lg hover:scale-105"
              >
                <span>Begin Presentation</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* SLIDE 2: Overall Sales & Profit Performance */}
        {currentSlide === 2 && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
            <SalesProfitSection currencyMode={currencyMode} timeRange={timeRange} />
          </div>
        )}

        {/* SLIDE 3: Category & Product Performance */}
        {currentSlide === 3 && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
            <CategoryProductSection currencyMode={currencyMode} />
          </div>
        )}

        {/* SLIDE 4: Order Status & Revenue Loss */}
        {currentSlide === 4 && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
            <OrderStatusLossSection currencyMode={currencyMode} />
          </div>
        )}

        {/* SLIDE 5: Payment, Fulfillment & Geographic Performance */}
        {currentSlide === 5 && (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
            <PaymentFulfillmentGeoSection currencyMode={currencyMode} />
          </div>
        )}
      </div>

      {/* Slide Navigation Dots at bottom */}
      <div className="p-4 border-t border-slate-800/80 bg-slate-900/40 flex items-center justify-center gap-2">
        {[1, 2, 3, 4, 5].map((num) => (
          <button
            key={num}
            onClick={() => setCurrentSlide(num)}
            className={`w-2.5 h-2.5 rounded-full transition-all ${
              currentSlide === num
                ? 'bg-amber-400 w-8'
                : 'bg-slate-700 hover:bg-slate-500'
            }`}
            title={`Jump to Slide ${num}`}
          />
        ))}
      </div>
    </div>
  );
};
