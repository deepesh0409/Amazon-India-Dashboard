import React from 'react';
import {
  PackageCheck,
  Truck,
  RotateCcw,
  Ban,
  AlertOctagon,
  Percent,
  Sparkles,
  TrendingDown,
  Info,
  DollarSign,
  ShieldAlert,
  ArrowRight,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { ORDER_STATUS_SUMMARY, CATEGORIES_DATA } from '../data/mockData';
import { CurrencyMode } from '../types/dashboard';
import { formatINR, formatNumber, formatPercent } from '../utils/formatters';
import { MetricCard } from './MetricCard';

interface OrderStatusLossSectionProps {
  currencyMode: CurrencyMode;
}

export const OrderStatusLossSection: React.FC<OrderStatusLossSectionProps> = ({
  currencyMode,
}) => {
  const statusData = ORDER_STATUS_SUMMARY;

  // Donut chart of Order Completion
  const orderPieData = [
    { name: 'Delivered', value: statusData.deliveredOrders, color: '#10b981' },
    { name: 'Shipped (In-Transit)', value: statusData.shippedOrders, color: '#3b82f6' },
    { name: 'Returned', value: statusData.returnedOrders, color: '#f59e0b' },
    { name: 'Cancelled', value: statusData.cancelledOrders, color: '#ef4444' },
  ];

  // Category-wise Returns & Cancellations chart data
  const categoryLossData = CATEGORIES_DATA.map((cat) => ({
    name: cat.name.split(' ')[0],
    fullName: cat.name,
    returnRate: cat.returnRate,
    cancellationRate: cat.cancellationRate,
    totalLossRate: Number((cat.returnRate + cat.cancellationRate).toFixed(1)),
    sales: cat.sales,
    returnLossEstimated: Math.round(cat.sales * (cat.returnRate / 100)),
  }));

  const totalLostRevenue =
    statusData.estimatedReturnRevenueLoss + statusData.estimatedCancellationRevenueLoss;

  return (
    <section className="space-y-6">
      {/* Slide 4 Header Banner */}
      <div className="bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 text-white rounded-2xl p-5 sm:p-6 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white font-bold text-xs uppercase tracking-wider backdrop-blur-xs">
              Slide 4 of 5
            </span>
            <span className="text-rose-200 text-xs font-semibold">AMAZON INDIA DASHBOARD</span>
          </div>
          <span className="text-xs bg-rose-500/30 px-3 py-1 rounded-full border border-rose-300/30 font-medium">
            Executive Pillar: Operational Leakage & Retention
          </span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          3) Order Status & Revenue Loss
        </h2>

        <div className="mt-2 text-rose-100 text-sm font-medium flex items-center gap-2">
          <span className="font-bold text-amber-300">Business Question:</span>
          <span className="underline decoration-rose-300 decoration-1 underline-offset-4">
            How many orders are successfully completed and how many are being lost?
          </span>
        </div>
      </div>

      {/* The 4 Order Statuses & 2 Core Rates required by Slide 4 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Delivered Orders */}
        <MetricCard
          title="Delivered Orders"
          value={formatNumber(statusData.deliveredOrders)}
          subValue="81.7% fulfillment rate"
          change={{ value: '+19.2%', isPositive: true }}
          variant="success"
          icon={<PackageCheck className="w-4 h-4" />}
        />

        {/* Shipped Orders */}
        <MetricCard
          title="Shipped Orders"
          value={formatNumber(statusData.shippedOrders)}
          subValue="5.8% active in-transit"
          variant="primary"
          icon={<Truck className="w-4 h-4" />}
        />

        {/* Returned Orders */}
        <MetricCard
          title="Returned Orders"
          value={formatNumber(statusData.returnedOrders)}
          subValue="Post-delivery returns"
          change={{ value: '+1.2%', isPositive: false }}
          variant="warning"
          icon={<RotateCcw className="w-4 h-4" />}
        />

        {/* Cancelled Orders */}
        <MetricCard
          title="Cancelled Orders"
          value={formatNumber(statusData.cancelledOrders)}
          subValue="Pre-delivery cancels"
          change={{ value: '-0.8%', isPositive: true }}
          variant="danger"
          icon={<Ban className="w-4 h-4" />}
        />

        {/* Return Rate % */}
        <MetricCard
          title="Return Rate %"
          value={formatPercent(statusData.returnRate, 1)}
          subValue="Industry avg: 8.5%"
          change={{ value: '-0.3%', isPositive: true }}
          variant="warning"
          glossaryKey="Return Rate %"
          icon={<Percent className="w-4 h-4" />}
        />

        {/* Cancellation Rate % */}
        <MetricCard
          title="Cancellation Rate %"
          value={formatPercent(statusData.cancellationRate, 1)}
          subValue="Industry avg: 6.0%"
          change={{ value: '-0.5%', isPositive: true }}
          variant="danger"
          glossaryKey="Cancellation Rate %"
          icon={<Percent className="w-4 h-4" />}
        />
      </div>

      {/* Revenue Loss Impact Analysis Card */}
      <div className="bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-3 bg-red-100 text-red-700 rounded-2xl shrink-0">
              <AlertOctagon className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-red-700">
                Financial Leakage Analysis for Ravi
              </span>
              <h3 className="text-lg font-extrabold text-slate-900 mt-0.5">
                Total Revenue Impact of Returns & Cancellations:{' '}
                <span className="text-red-600 font-mono">
                  {formatINR(totalLostRevenue, currencyMode)}
                </span>
              </h3>
              <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
                Out of 2.88 Lakh placed orders, <strong>36,065 orders (12.5%)</strong> were either returned or cancelled, resulting in lost gross sales and direct non-recoverable reverse shipping penalties.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 sm:gap-4 shrink-0 bg-white/80 p-3 rounded-xl border border-red-200">
            <div className="text-center px-2">
              <div className="text-[11px] text-slate-500 font-medium">Return GMV Loss</div>
              <div className="text-sm sm:text-base font-extrabold text-amber-700 font-mono mt-0.5">
                {formatINR(statusData.estimatedReturnRevenueLoss, currencyMode)}
              </div>
            </div>
            <div className="text-center px-2 border-x border-slate-200">
              <div className="text-[11px] text-slate-500 font-medium">Cancelled GMV</div>
              <div className="text-sm sm:text-base font-extrabold text-rose-700 font-mono mt-0.5">
                {formatINR(statusData.estimatedCancellationRevenueLoss, currencyMode)}
              </div>
            </div>
            <div className="text-center px-2">
              <div className="text-[11px] text-slate-500 font-medium">Reverse Courier Cost</div>
              <div className="text-sm sm:text-base font-extrabold text-slate-900 font-mono mt-0.5">
                {formatINR(statusData.reverseLogisticsCost, currencyMode)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Category-wise Returns & Cancellations Chart (Slide 4 Requirement) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category breakdown bar chart */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-rose-600" />
                Category-wise Returns & Cancellations (%)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Identifying departments with elevated customer friction and return ratios
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 border border-rose-200">
              Apparel Peak: 14.6% Return Rate
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryLossData} margin={{ top: 10, right: 10, left: -10, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis
                  dataKey="name"
                  tick={{ fill: '#475569', fontSize: 11, fontWeight: 600 }}
                  tickLine={false}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis
                  tick={{ fill: '#64748b', fontSize: 11 }}
                  tickLine={false}
                  axisLine={false}
                  tickFormatter={(val) => `${val}%`}
                />
                <Tooltip
                  formatter={(val: any, name: any, item: any) => {
                    if (name === 'Return Rate %') return [`${val}%`, 'Return Rate'];
                    if (name === 'Cancellation Rate %') return [`${val}%`, 'Cancellation Rate'];
                    return [val, name];
                  }}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#1e293b',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: 10 }} />
                <Bar
                  dataKey="returnRate"
                  name="Return Rate %"
                  fill="#f59e0b"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={32}
                />
                <Bar
                  dataKey="cancellationRate"
                  name="Cancellation Rate %"
                  fill="#ef4444"
                  radius={[6, 6, 0, 0]}
                  maxBarSize={32}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Order Completion Status Distribution Donut */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <h4 className="text-sm font-bold text-slate-900 mb-1">
              Order Lifecycle Distribution
            </h4>
            <p className="text-xs text-slate-500 mb-3">
              Total placed orders: {formatNumber(statusData.totalOrders)}
            </p>

            <div className="h-44 w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={orderPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {orderPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: any, name: any) => [
                      `${formatNumber(Number(value))} (${(
                        (Number(value) / statusData.totalOrders) *
                        100
                      ).toFixed(1)}%)`,
                      name,
                    ]}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-lg font-extrabold text-slate-900">81.7%</span>
                <span className="text-[10px] text-slate-500 font-semibold uppercase">Delivered</span>
              </div>
            </div>

            <div className="space-y-1.5 mt-2 text-xs">
              {orderPieData.map((item) => (
                <div key={item.name} className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-slate-600">
                    <span
                      className="w-2.5 h-2.5 rounded-full inline-block"
                      style={{ backgroundColor: item.color }}
                    ></span>
                    {item.name}
                  </span>
                  <span className="font-semibold text-slate-900 font-mono">
                    {formatNumber(item.value)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-slate-500 text-[11px]">
            <strong>Root cause:</strong> 64% of apparel returns cite "Size/Fit issue", while 78% of cancellations happen within 2 hours of order placement.
          </div>
        </div>
      </div>

      {/* Slide 4: Expected Insight Box */}
      <div className="bg-rose-50/70 border border-rose-200 rounded-2xl p-5 text-rose-950 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-rose-100 text-rose-800 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-sm text-rose-950 uppercase tracking-wide">
                Expected Insight for Ravi:
              </h4>
              <span className="text-[11px] bg-rose-200 text-rose-900 px-2 py-0.5 rounded font-semibold">
                Loss Containment Priority
              </span>
            </div>
            <p className="text-xs sm:text-sm text-rose-900 leading-relaxed">
              <strong>Manoj's Executive Assessment:</strong> With 81.7% delivered orders, our baseline operations are steady. However, <strong>returns and cancellations represent our largest preventable revenue leak (₹6.49 Cr total GMV impacted)</strong>. Apparel & Fashion is the primary hotspot with a <strong>14.6% return rate</strong> (2.5x higher than Electronics). Reducing Apparel returns by just 3% would save approximately ₹33.6 Lakhs in courier fees and boost overall net margin by 0.7%.
            </p>
            <div className="pt-2 flex flex-wrap gap-4 text-xs font-semibold text-rose-900">
              <span>• Total Lost Volume: <strong>36,065 orders</strong></span>
              <span>• Reverse Freight Penalty: <strong>₹43.27 Lakhs</strong></span>
              <span>• Opportunity: Convert 30% of fashion returns to instant store credit exchanges</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
