import React, { useState } from 'react';
import { HelpCircle, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { GLOSSARY } from '../utils/formatters';

interface MetricCardProps {
  title: string;
  value: string;
  subValue?: string;
  change?: {
    value: string;
    isPositive: boolean;
    period?: string;
  };
  icon?: React.ReactNode;
  variant?: 'default' | 'primary' | 'success' | 'warning' | 'danger' | 'purple';
  glossaryKey?: string;
  badge?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subValue,
  change,
  icon,
  variant = 'default',
  glossaryKey,
  badge,
}) => {
  const [showTooltip, setShowTooltip] = useState(false);
  const glossaryItem = glossaryKey ? GLOSSARY[glossaryKey] || GLOSSARY[title] : GLOSSARY[title];

  const variantStyles = {
    default: 'bg-white border-slate-200 text-slate-900',
    primary: 'bg-gradient-to-br from-blue-50/70 to-indigo-50/40 border-blue-200 text-slate-900',
    success: 'bg-gradient-to-br from-emerald-50/70 to-teal-50/40 border-emerald-200 text-slate-900',
    warning: 'bg-gradient-to-br from-amber-50/70 to-orange-50/40 border-amber-200 text-slate-900',
    danger: 'bg-gradient-to-br from-rose-50/70 to-red-50/40 border-rose-200 text-slate-900',
    purple: 'bg-gradient-to-br from-purple-50/70 to-violet-50/40 border-purple-200 text-slate-900',
  };

  const iconBgStyles = {
    default: 'bg-slate-100 text-slate-600',
    primary: 'bg-blue-100 text-blue-700',
    success: 'bg-emerald-100 text-emerald-700',
    warning: 'bg-amber-100 text-amber-700',
    danger: 'bg-rose-100 text-rose-700',
    purple: 'bg-purple-100 text-purple-700',
  };

  return (
    <div
      className={`relative p-5 rounded-2xl border transition-all duration-200 hover:shadow-md ${variantStyles[variant]}`}
    >
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-1.5">
          <span className="text-xs font-semibold text-slate-600 tracking-wide uppercase">
            {title}
          </span>
          {glossaryItem && (
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowTooltip(!showTooltip)}
                onMouseEnter={() => setShowTooltip(true)}
                onMouseLeave={() => setShowTooltip(false)}
                className="text-slate-400 hover:text-slate-600 transition-colors p-0.5 rounded-full focus:outline-none"
                aria-label={`Explain ${title}`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
              </button>

              {showTooltip && (
                <div className="absolute z-50 left-0 top-6 w-64 p-3 bg-slate-900 text-white rounded-xl shadow-xl text-xs space-y-1.5 animate-in fade-in zoom-in-95 pointer-events-none">
                  <p className="font-bold text-amber-400">{glossaryItem.title}</p>
                  <p className="text-slate-300 leading-relaxed">{glossaryItem.explanation}</p>
                  <div className="pt-1 border-t border-slate-700 text-slate-400 text-[11px]">
                    <span className="font-semibold text-slate-200">Why it matters to Ravi:</span>{' '}
                    {glossaryItem.whyItMatters}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {badge ? (
          <span className="px-2 py-0.5 text-[11px] font-medium rounded-full bg-slate-100 text-slate-600 border border-slate-200">
            {badge}
          </span>
        ) : icon ? (
          <div className={`p-2 rounded-xl ${iconBgStyles[variant]}`}>
            {icon}
          </div>
        ) : null}
      </div>

      <div className="mt-1">
        <div className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900">
          {value}
        </div>
        {subValue && (
          <div className="text-xs text-slate-500 font-medium mt-0.5">{subValue}</div>
        )}
      </div>

      {change && (
        <div className="mt-3 flex items-center gap-1.5 text-xs">
          <span
            className={`inline-flex items-center gap-0.5 font-semibold px-1.5 py-0.5 rounded-md ${
              change.isPositive
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-rose-100 text-rose-800'
            }`}
          >
            {change.isPositive ? (
              <TrendingUp className="w-3.5 h-3.5" />
            ) : (
              <TrendingDown className="w-3.5 h-3.5" />
            )}
            {change.value}
          </span>
          <span className="text-slate-500">{change.period || 'vs last year'}</span>
        </div>
      )}
    </div>
  );
};
