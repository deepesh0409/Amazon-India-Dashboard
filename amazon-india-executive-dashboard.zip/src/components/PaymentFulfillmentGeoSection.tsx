import React, { useState } from 'react';
import {
  CreditCard,
  Truck,
  MapPin,
  Sparkles,
  Smartphone,
  Banknote,
  Building2,
  Zap,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowUpDown,
  Search,
  Filter,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  PAYMENT_METHODS,
  FULFILLMENT_METHODS,
  STATE_PERFORMANCE,
} from '../data/mockData';
import { CurrencyMode, StatePerformance } from '../types/dashboard';
import { formatINR, formatNumber, formatPercent } from '../utils/formatters';

interface PaymentFulfillmentGeoSectionProps {
  currencyMode: CurrencyMode;
}

export const PaymentFulfillmentGeoSection: React.FC<PaymentFulfillmentGeoSectionProps> = ({
  currencyMode,
}) => {
  const [activeChannelView, setActiveChannelView] = useState<'all' | 'payment' | 'fulfillment' | 'geo'>('all');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [stateSearch, setStateSearch] = useState<string>('');
  const [stateSortField, setStateSortField] = useState<keyof StatePerformance>('sales');
  const [stateSortAsc, setStateSortAsc] = useState<boolean>(false);

  // Filtered and sorted states
  const filteredStates = STATE_PERFORMANCE.filter((st) => {
    const matchesRegion = selectedRegion === 'all' || st.region === selectedRegion;
    const matchesSearch =
      st.state.toLowerCase().includes(stateSearch.toLowerCase()) ||
      st.stateCode.toLowerCase().includes(stateSearch.toLowerCase());
    return matchesRegion && matchesSearch;
  }).sort((a, b) => {
    const aVal = a[stateSortField];
    const bVal = b[stateSortField];
    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return stateSortAsc ? aVal - bVal : bVal - aVal;
    }
    return stateSortAsc
      ? String(aVal).localeCompare(String(bVal))
      : String(bVal).localeCompare(String(aVal));
  });

  const handleStateSort = (field: keyof StatePerformance) => {
    if (stateSortField === field) {
      setStateSortAsc(!stateSortAsc);
    } else {
      setStateSortField(field);
      setStateSortAsc(false);
    }
  };

  // Payment chart data
  const paymentChartData = PAYMENT_METHODS.map((p) => ({
    name: p.method,
    Sales: p.sales / 10000000,
    Profit: p.profit / 10000000,
    salesRaw: p.sales,
    profitRaw: p.profit,
    margin: p.profitMargin,
    rto: p.rtoRate,
  }));

  // Fulfillment chart data
  const fulfillmentChartData = FULFILLMENT_METHODS.map((f) => ({
    name: f.method,
    fullName: f.name,
    Sales: f.sales / 10000000,
    Profit: f.profit / 10000000,
    salesRaw: f.sales,
    profitRaw: f.profit,
    margin: f.profitMargin,
    deliveryDays: f.avgDeliveryDays,
  }));

  // Colors for Payment methods
  const PAYMENT_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#06b6d4', '#ec4899'];
  const FULFILLMENT_COLORS = ['#f59e0b', '#3b82f6', '#64748b'];

  return (
    <section className="space-y-6">
      {/* Slide 5 Header Banner */}
      <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white rounded-2xl p-5 sm:p-6 shadow-md">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-white/20 text-white font-bold text-xs uppercase tracking-wider backdrop-blur-xs">
              Slide 5 of 5
            </span>
            <span className="text-emerald-100 text-xs font-semibold">AMAZON INDIA DASHBOARD</span>
          </div>
          <span className="text-xs bg-emerald-500/30 px-3 py-1 rounded-full border border-emerald-300/30 font-medium">
            Executive Pillar: Channels & Geographies
          </span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          4) Payment, Fulfillment & Geographic Performance
        </h2>

        <div className="mt-2 text-emerald-100 text-sm font-medium flex items-center gap-2">
          <span className="font-bold text-amber-300">Business Question:</span>
          <span className="underline decoration-emerald-300 decoration-1 underline-offset-4">
            Which payment methods, fulfillment methods and states are generating business?
          </span>
        </div>
      </div>

      {/* Slide 5 Required Section A & B: Payment & Fulfillment Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Payment Methods Breakdown (Sales & Profit by Payment Method) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900">
                  Sales & Profit by Payment Method
                </h3>
              </div>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-blue-50 text-blue-700">
                UPI Dominant (44%)
              </span>
            </div>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={paymentChartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="name" tick={{ fill: '#475569', fontSize: 11 }} tickLine={false} />
                  <YAxis
                    tick={{ fill: '#64748b', fontSize: 11 }}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(val) => `₹${val}Cr`}
                  />
                  <Tooltip
                    formatter={(val: any, name: any, item: any) => {
                      if (name === 'Sales (₹ Cr)') {
                        return [formatINR(item.payload.salesRaw, currencyMode), 'Sales'];
                      }
                      if (name === 'Profit (₹ Cr)') {
                        return [formatINR(item.payload.profitRaw, currencyMode), 'Net Profit'];
                      }
                      return [val, name];
                    }}
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#1e293b',
                      borderRadius: '12px',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                  <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: 8 }} />
                  <Bar
                    dataKey="Sales"
                    name="Sales (₹ Cr)"
                    fill="#3b82f6"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={28}
                  />
                  <Bar
                    dataKey="Profit"
                    name="Profit (₹ Cr)"
                    fill="#10b981"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={28}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Payment Method Details Table */}
            <div className="mt-4 space-y-2">
              {PAYMENT_METHODS.map((pm) => (
                <div
                  key={pm.method}
                  className="flex items-center justify-between text-xs p-2 rounded-xl bg-slate-50 hover:bg-slate-100 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-800">{pm.label}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-slate-900 font-mono">
                      {formatINR(pm.sales, currencyMode)}
                    </span>
                    <span className="font-semibold text-emerald-600 font-mono">
                      {pm.profitMargin}% margin
                    </span>
                    <span
                      className={`px-1.5 py-0.2 rounded font-mono font-bold text-[10px] ${
                        pm.rtoRate > 10 ? 'bg-rose-100 text-rose-800' : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {pm.rtoRate}% RTO
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-slate-600 text-[11px]">
            <strong className="text-rose-700">Warning for Ravi:</strong> COD represents 15% of sales but has a staggering <strong>17.8% Return-to-Origin rate</strong>, dragging profit margin down to only 11% compared to 22% in UPI.
          </div>
        </div>

        {/* Fulfillment Methods Breakdown (Sales & Profit by Fulfillment Method) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-amber-600" />
                <h3 className="text-base font-bold text-slate-900">
                  Sales & Profit by Fulfillment Method
                </h3>
              </div>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-amber-50 text-amber-800">
                FBA Prime: 62% Share
              </span>
            </div>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={fulfillmentChartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="name" tick={{ fill: '#475569', fontSize: 11 }} tickLine={false} />
                  <YAxis
                    tick={{ fill: '#64748b', fontSize: 11 }}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(val) => `₹${val}Cr`}
                  />
                  <Tooltip
                    formatter={(val: any, name: any, item: any) => {
                      if (name === 'Sales (₹ Cr)') {
                        return [formatINR(item.payload.salesRaw, currencyMode), 'Sales'];
                      }
                      if (name === 'Profit (₹ Cr)') {
                        return [formatINR(item.payload.profitRaw, currencyMode), 'Net Profit'];
                      }
                      return [val, name];
                    }}
                    contentStyle={{
                      backgroundColor: '#0f172a',
                      borderColor: '#1e293b',
                      borderRadius: '12px',
                      color: '#fff',
                      fontSize: '12px',
                    }}
                  />
                  <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: 8 }} />
                  <Bar
                    dataKey="Sales"
                    name="Sales (₹ Cr)"
                    fill="#f59e0b"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={36}
                  />
                  <Bar
                    dataKey="Profit"
                    name="Profit (₹ Cr)"
                    fill="#10b981"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={36}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Fulfillment Comparison Cards */}
            <div className="mt-4 grid grid-cols-3 gap-2">
              {FULFILLMENT_METHODS.map((fm) => (
                <div
                  key={fm.method}
                  className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between"
                >
                  <div>
                    <div className="font-bold text-slate-900 text-xs">{fm.method}</div>
                    <div className="text-[10px] text-slate-500 font-medium truncate mt-0.5">
                      {fm.sharePercentage}% volume
                    </div>
                  </div>
                  <div className="mt-2 pt-2 border-t border-slate-200 text-slate-700 text-[11px] space-y-0.5">
                    <div className="font-bold text-slate-900 font-mono">
                      {formatINR(fm.sales, currencyMode)}
                    </div>
                    <div className="text-emerald-700 font-semibold">{fm.profitMargin}% margin</div>
                    <div className="text-slate-500 text-[10px]">{fm.avgDeliveryDays} days avg</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 text-slate-600 text-[11px]">
            <strong className="text-amber-700">Fulfillment Insight:</strong> FBA achieves <strong>98.7% on-time delivery</strong> and delivers in 1.6 days vs 5.2 days for Seller Fulfilled, protecting customer satisfaction and prime ranking.
          </div>
        </div>
      </div>

      {/* Slide 5 Required Section C: State-wise Performance (Sales, Profit, Orders) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-emerald-600" />
              <h3 className="text-base font-bold text-slate-900">
                Geographic Performance: State-wise Sales, Profit & Orders
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Regional demand breakdown across Indian states and union territories
            </p>
          </div>

          {/* Controls: Region Filter & Search */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search state or code..."
                value={stateSearch}
                onChange={(e) => setStateSearch(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs font-semibold text-slate-600">
              {['all', 'North', 'South', 'West', 'East'].map((region) => (
                <button
                  key={region}
                  onClick={() => setSelectedRegion(region)}
                  className={`px-2.5 py-1 rounded-md transition-colors ${
                    selectedRegion === region
                      ? 'bg-white text-emerald-800 shadow-xs'
                      : 'hover:text-slate-900'
                  }`}
                >
                  {region === 'all' ? 'All India' : region}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* State Performance Table with Sortable Columns */}
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-semibold border-b border-slate-200">
                <th className="p-3 w-12 text-center">Rank</th>
                <th
                  onClick={() => handleStateSort('state')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors"
                >
                  <div className="flex items-center gap-1">
                    <span>State / Union Territory</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="p-3">Region</th>
                <th
                  onClick={() => handleStateSort('sales')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>State-wise Sales</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleStateSort('profit')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>State-wise Profit</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleStateSort('orders')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>State-wise Orders</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleStateSort('profitMargin')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1">
                    <span>Margin %</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th
                  onClick={() => handleStateSort('returnRate')}
                  className="p-3 cursor-pointer hover:text-slate-900 transition-colors text-center"
                >
                  <div className="flex items-center justify-center gap-1">
                    <span>Return Rate</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </div>
                </th>
                <th className="p-3">Top Category</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-sans">
              {filteredStates.map((st, index) => {
                const shareOfTotal = ((st.sales / 480000000) * 100).toFixed(1);
                return (
                  <tr key={st.stateCode} className="hover:bg-slate-50/80 transition-colors">
                    <td className="p-3 text-center font-bold text-slate-400 font-mono">
                      #{index + 1}
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <div className="font-bold text-slate-900">{st.state}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        Code: {st.stateCode} • {shareOfTotal}% national share
                      </div>
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                          st.region === 'West'
                            ? 'bg-amber-100 text-amber-800'
                            : st.region === 'South'
                            ? 'bg-blue-100 text-blue-800'
                            : st.region === 'North'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-emerald-100 text-emerald-800'
                        }`}
                      >
                        {st.region}
                      </span>
                    </td>
                    <td className="p-3 text-right font-bold text-slate-900 font-mono whitespace-nowrap">
                      {formatINR(st.sales, currencyMode)}
                    </td>
                    <td className="p-3 text-right font-bold text-emerald-600 font-mono whitespace-nowrap">
                      {formatINR(st.profit, currencyMode)}
                    </td>
                    <td className="p-3 text-right font-mono text-slate-700 whitespace-nowrap">
                      {formatNumber(st.orders)}
                    </td>
                    <td className="p-3 text-right font-mono font-semibold text-slate-800">
                      <span className="px-1.5 py-0.5 rounded bg-slate-100">{st.profitMargin}%</span>
                    </td>
                    <td className="p-3 text-center font-mono">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                          st.returnRate > 10
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {st.returnRate}%
                      </span>
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      <span className="text-slate-600 text-[11px] font-medium">
                        {st.topCategory}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Slide 5: Expected Insight Box */}
      <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-5 text-emerald-950 shadow-xs">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-sm text-emerald-950 uppercase tracking-wide">
                Expected Insight for Ravi:
              </h4>
              <span className="text-[11px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded font-semibold">
                Market Geography & Channel Optimization
              </span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-900 leading-relaxed">
              <strong>Manoj's Executive Assessment:</strong> Three states—<strong>Maharashtra (₹10.45 Cr), Karnataka (₹8.15 Cr), and Delhi NCR (₹7.35 Cr)</strong>—generate more than <strong>54% of our total revenue and profit</strong>. High prepaid penetration in Bangalore, Mumbai, and Hyderabad explains their superior profitability (21-22% margin). Conversely, Uttar Pradesh exhibits higher COD adoption resulting in an 11.2% return rate.
            </p>
            <div className="pt-2 flex flex-wrap gap-4 text-xs font-semibold text-emerald-900">
              <span>• Top Hub: Maharashtra leads with ₹10.45 Cr sales & 62,700 orders</span>
              <span>• Fulfillment Winner: FBA generates 62% volume with 21% net margin</span>
              <span>• Payment Channel Winner: UPI powers ₹21.12 Cr with only 2.4% RTO</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
