import React from 'react';
import {
  BarChart3,
  SlidersHorizontal,
  Presentation,
  FileText,
  Printer,
  ChevronDown,
  Layers,
  Sparkles,
  Info,
} from 'lucide-react';
import { CurrencyMode, TimeRange } from '../types/dashboard';

interface HeaderProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currencyMode: CurrencyMode;
  setCurrencyMode: (mode: CurrencyMode) => void;
  timeRange: TimeRange;
  setTimeRange: (range: TimeRange) => void;
  isPresentationMode: boolean;
  setIsPresentationMode: (val: boolean) => void;
  onPrint: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  setCurrentTab,
  currencyMode,
  setCurrencyMode,
  timeRange,
  setTimeRange,
  isPresentationMode,
  setIsPresentationMode,
  onPrint,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top corporate banner */}
      <div className="bg-slate-900 text-white px-4 sm:px-6 py-2 text-xs flex flex-wrap items-center justify-between gap-2 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-semibold border border-indigo-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            Management Review Mode
          </span>
          <span className="text-slate-300 hidden sm:inline">
            Internal Operations Briefing for <strong className="text-white">Ravi</strong> by <strong className="text-amber-400">Manoj</strong>
          </span>
        </div>

        <div className="flex items-center gap-4 text-slate-300">
          <span className="hidden md:inline text-[11px] bg-slate-800 px-2.5 py-0.5 rounded text-slate-300">
            Marketplace: Amazon.in | FY 2023-2024
          </span>
          <button
            onClick={() => setCurrentTab('memo')}
            className="hover:text-amber-300 transition-colors flex items-center gap-1 text-[11px]"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Manoj's Executive Note</span>
          </button>
        </div>
      </div>

      {/* Main header bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* Logos & Title */}
          <div className="flex items-center gap-4">
            {/* Sapphire IQ branding */}
            <div className="flex items-center gap-2">
              <div className="h-9 w-9 rounded-xl bg-gradient-to-tr from-indigo-700 via-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-sm ring-1 ring-indigo-500/20">
                <div className="flex flex-col items-center justify-center -space-y-0.5">
                  <span className="text-[10px] font-black tracking-tighter">SQ</span>
                  <BarChart3 className="w-4 h-4 text-amber-300" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1">
                  <span className="font-extrabold tracking-tight text-indigo-900 text-lg leading-tight">
                    SAPPHiRE<span className="text-blue-600">IQ</span>
                  </span>
                </div>
                <div className="text-[10px] tracking-wider text-slate-600 font-semibold uppercase">
                  Analytics & Operations
                </div>
              </div>
            </div>

            <div className="h-6 w-px bg-slate-200"></div>

            {/* Amazon India branding */}
            <div className="flex flex-col">
              <div className="flex items-baseline gap-1">
                <span className="font-black text-xl tracking-tight text-slate-900">amazon</span>
                <span className="text-xs font-bold text-amber-600 bg-amber-50 px-1.5 py-0.2 rounded border border-amber-200">
                  India .in
                </span>
              </div>
              <div className="w-16 h-1 bg-gradient-to-r from-amber-500 to-amber-600 rounded-full -mt-0.5"></div>
            </div>

            <div className="hidden sm:block h-6 w-px bg-slate-200"></div>

            <div className="hidden sm:block">
              <h1 className="text-sm font-bold text-slate-900 leading-none">
                Executive Management Dashboard
              </h1>
              <p className="text-[11px] text-slate-600 mt-0.5">
                Prepared for Non-Technical Leadership Review
              </p>
            </div>
          </div>

          {/* Controls & Mode toggles */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Currency Format Toggle */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-600">
              <button
                type="button"
                onClick={() => setCurrencyMode('crores')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  currencyMode === 'crores'
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'hover:text-slate-900'
                }`}
                title="Format as Crores (₹ Cr)"
              >
                ₹ Cr
              </button>
              <button
                type="button"
                onClick={() => setCurrencyMode('lakhs')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  currencyMode === 'lakhs'
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'hover:text-slate-900'
                }`}
                title="Format as Lakhs (₹ L)"
              >
                ₹ Lakhs
              </button>
              <button
                type="button"
                onClick={() => setCurrencyMode('standard')}
                className={`px-2.5 py-1 rounded-md transition-all ${
                  currencyMode === 'standard'
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'hover:text-slate-900'
                }`}
                title="Standard Full Number"
              >
                Full ₹
              </button>
            </div>

            {/* Time Period Filter */}
            <div className="relative">
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value as TimeRange)}
                className="bg-white border border-slate-200 text-slate-800 text-xs font-semibold rounded-lg px-3 py-1.5 pr-7 appearance-none shadow-xs hover:border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="FY24">FY2023-24 (Full Year)</option>
                <option value="Q4-24">Q4 (Jan - Mar '24)</option>
                <option value="Q3-24">Q3 (Oct - Dec '23 Festive)</option>
                <option value="Q2-24">Q2 (Jul - Sep '23 Prime)</option>
                <option value="Q1-24">Q1 (Apr - Jun '23 Summer)</option>
                <option value="H2-24">H2 (Festive Half Oct-Mar)</option>
                <option value="H1-24">H1 (Summer Half Apr-Sep)</option>
              </select>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Presentation Mode Toggle */}
            <button
              onClick={() => setIsPresentationMode(!isPresentationMode)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                isPresentationMode
                  ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
              title="Toggle Slide Deck Presentation for Ravi"
            >
              <Presentation className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Slides Mode</span>
            </button>

            {/* Print / Save Report Button */}
            <button
              onClick={onPrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 text-white hover:bg-slate-800 shadow-xs transition-colors"
              title="Print or Export PDF for Ravi"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print / PDF</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation (Directly mapping the 4 slides + Overview + Memo) */}
        {!isPresentationMode && (
          <nav className="flex items-center gap-1 overflow-x-auto pt-3 mt-2 border-t border-slate-100 no-scrollbar">
            <button
              onClick={() => setCurrentTab('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                currentTab === 'all'
                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Full Master Dashboard</span>
            </button>

            <button
              onClick={() => setCurrentTab('sales')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                currentTab === 'sales'
                  ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-700 text-[10px] font-bold flex items-center justify-center">1</span>
              <span>1) Sales & Profit</span>
            </button>

            <button
              onClick={() => setCurrentTab('category')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                currentTab === 'category'
                  ? 'bg-purple-50 text-purple-700 border border-purple-200 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-purple-100 text-purple-700 text-[10px] font-bold flex items-center justify-center">2</span>
              <span>2) Category & Products</span>
            </button>

            <button
              onClick={() => setCurrentTab('orders')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                currentTab === 'orders'
                  ? 'bg-rose-50 text-rose-700 border border-rose-200 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-rose-100 text-rose-700 text-[10px] font-bold flex items-center justify-center">3</span>
              <span>3) Order Status & Loss</span>
            </button>

            <button
              onClick={() => setCurrentTab('channels')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                currentTab === 'channels'
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold flex items-center justify-center">4</span>
              <span>4) Payment, Fulfillment & Geo</span>
            </button>

            <button
              onClick={() => setCurrentTab('memo')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                currentTab === 'memo'
                  ? 'bg-amber-50 text-amber-800 border border-amber-200 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-amber-600" />
              <span>Ravi's Management Memo</span>
            </button>
          </nav>
        )}
      </div>
    </header>
  );
};
