import { CurrencyMode } from '../types/dashboard';

/**
 * Format currency in INR with options for Crores, Lakhs, or full Indian numbering format
 */
export function formatINR(value: number, mode: CurrencyMode = 'crores', decimals = 2): string {
  if (value === 0) return '₹0';
  
  const isNegative = value < 0;
  const absVal = Math.abs(value);

  if (mode === 'crores') {
    if (absVal >= 10000000) {
      const cr = absVal / 10000000;
      return `${isNegative ? '-' : ''}₹${cr.toFixed(decimals)} Cr`;
    } else if (absVal >= 100000) {
      const lakh = absVal / 100000;
      return `${isNegative ? '-' : ''}₹${lakh.toFixed(decimals)} L`;
    } else {
      return `${isNegative ? '-' : ''}₹${absVal.toLocaleString('en-IN')}`;
    }
  }

  if (mode === 'lakhs') {
    if (absVal >= 100000) {
      const lakh = absVal / 100000;
      return `${isNegative ? '-' : ''}₹${lakh.toFixed(decimals)} L`;
    } else {
      return `${isNegative ? '-' : ''}₹${absVal.toLocaleString('en-IN')}`;
    }
  }

  // Standard Indian numbering (e.g. ₹1,25,00,000)
  return `${isNegative ? '-' : ''}₹${absVal.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
  })}`;
}

export function formatCompactNumber(value: number): string {
  if (value >= 10000000) {
    return `${(value / 10000000).toFixed(1)} Cr`;
  }
  if (value >= 100000) {
    return `${(value / 100000).toFixed(1)} L`;
  }
  if (value >= 1000) {
    return `${(value / 1000).toFixed(1)}k`;
  }
  return value.toLocaleString('en-IN');
}

export function formatNumber(value: number): string {
  return value.toLocaleString('en-IN');
}

export function formatPercent(value: number, decimals = 1): string {
  return `${value >= 0 ? '' : ''}${value.toFixed(decimals)}%`;
}

/**
 * Non-technical glossary tooltips specially designed for Ravi
 */
export const GLOSSARY: Record<string, { title: string; explanation: string; whyItMatters: string }> = {
  'Total Sales': {
    title: 'Gross Revenue (GMV)',
    explanation: 'Total rupee amount generated from all product orders placed by customers before deductions.',
    whyItMatters: 'Indicates top-line business scale and market demand.'
  },
  'Total Profit': {
    title: 'Net Contribution Margin',
    explanation: 'Revenue remaining after subtracting product cost of goods (COGS), marketplace referral fees, shipping, and return costs.',
    whyItMatters: 'Indicates actual cash earnings generated for the company.'
  },
  'Average Order Value': {
    title: 'Average Order Value (AOV)',
    explanation: 'Average basket size: Total Sales divided by Total Orders. E.g., each customer basket averages this amount.',
    whyItMatters: 'Increasing AOV boosts profitability without needing to acquire more customers.'
  },
  'Profit Margin %': {
    title: 'Profit Margin Percentage',
    explanation: 'How many paise of profit we keep from every ₹1 earned in sales (Profit ÷ Sales × 100).',
    whyItMatters: 'A healthy margin (15-25%) ensures business sustainability and funds reinvestment.'
  },
  'Return Rate %': {
    title: 'Customer Return Rate',
    explanation: 'Percentage of placed orders that were sent back by customers after delivery.',
    whyItMatters: 'High returns directly erode profits through two-way shipping costs and repackaging.'
  },
  'Cancellation Rate %': {
    title: 'Order Cancellation Rate',
    explanation: 'Percentage of placed orders cancelled before delivery (by customer or inventory shortage).',
    whyItMatters: 'Signals checkout friction, delayed dispatch, or buyer hesitation.'
  },
  'FBA': {
    title: 'Fulfilled by Amazon (FBA)',
    explanation: 'Our inventory is stored in Amazon warehouses; Amazon handles 1-2 day Prime packing and delivery.',
    whyItMatters: 'Yields higher conversion, Prime badge, and lower customer return disputes.'
  },
  'Easy Ship': {
    title: 'Amazon Easy Ship',
    explanation: 'We store goods in our own warehouse, and Amazon logistics courier picks up and delivers them.',
    whyItMatters: 'Saves warehouse storage fees while still leveraging Amazon courier network.'
  },
  'COD': {
    title: 'Cash on Delivery (COD)',
    explanation: 'Customer pays cash when the parcel arrives at their doorstep.',
    whyItMatters: 'COD orders suffer 3x higher refusal and Return-to-Origin (RTO) compared to prepaid UPI/Cards.'
  }
};
