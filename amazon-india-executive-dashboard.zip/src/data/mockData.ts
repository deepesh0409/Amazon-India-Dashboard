import {
  MonthlyTrend,
  CategoryData,
  ProductItem,
  OrderStatusMetrics,
  PaymentMethodData,
  FulfillmentMethodData,
  StatePerformance,
  ExecutiveInsight,
} from '../types/dashboard';

export const MONTHLY_DATA: MonthlyTrend[] = [
  { month: 'January', monthShort: 'Jan', sales: 31200000, profit: 5928000, orders: 15600, unitsSold: 24960, returnRate: 6.8, cancellationRate: 4.5 },
  { month: 'February', monthShort: 'Feb', sales: 29800000, profit: 5662000, orders: 14900, unitsSold: 23840, returnRate: 6.5, cancellationRate: 4.2 },
  { month: 'March', monthShort: 'Mar', sales: 34500000, profit: 6555000, orders: 17250, unitsSold: 27600, returnRate: 7.1, cancellationRate: 4.6 },
  { month: 'April', monthShort: 'Apr', sales: 36200000, profit: 6878000, orders: 18100, unitsSold: 28960, returnRate: 7.0, cancellationRate: 4.4 },
  { month: 'May (Summer Sale)', monthShort: 'May', sales: 44800000, profit: 8512000, orders: 22400, unitsSold: 35840, returnRate: 7.8, cancellationRate: 5.1 },
  { month: 'June', monthShort: 'Jun', sales: 35400000, profit: 6726000, orders: 17700, unitsSold: 28320, returnRate: 7.2, cancellationRate: 4.7 },
  { month: 'July (Prime Day)', monthShort: 'Jul', sales: 51200000, profit: 10240000, orders: 25600, unitsSold: 40960, returnRate: 8.2, cancellationRate: 5.3 },
  { month: 'August (Independence)', monthShort: 'Aug', sales: 41000000, profit: 7790000, orders: 20500, unitsSold: 32800, returnRate: 7.4, cancellationRate: 4.8 },
  { month: 'September', monthShort: 'Sep', sales: 38200000, profit: 7258000, orders: 19100, unitsSold: 30560, returnRate: 7.3, cancellationRate: 4.6 },
  { month: 'October (Great Indian Fest)', monthShort: 'Oct', sales: 68900000, profit: 13780000, orders: 34450, unitsSold: 55120, returnRate: 8.9, cancellationRate: 5.6 },
  { month: 'November (Diwali Surge)', monthShort: 'Nov', sales: 56400000, profit: 11280000, orders: 28200, unitsSold: 45120, returnRate: 8.0, cancellationRate: 5.0 },
  { month: 'December (Year End)', monthShort: 'Dec', sales: 42500000, profit: 8075000, orders: 21250, unitsSold: 34000, returnRate: 7.5, cancellationRate: 4.9 },
];

export const CATEGORIES_DATA: CategoryData[] = [
  {
    id: 'cat-elec',
    name: 'Electronics & Gadgets',
    sales: 184500000, // ₹18.45 Cr
    profit: 36900000, // 20.0%
    unitsSold: 92250,
    orders: 76875,
    profitMargin: 20.0,
    returnRate: 5.8,
    cancellationRate: 3.9,
    color: '#2563eb', // blue
    subCategories: ['True Wireless Earbuds', 'Smartwatches', 'Bluetooth Speakers', 'Power Banks', 'Smart Plugs'],
  },
  {
    id: 'cat-apparel',
    name: 'Apparel & Fashion',
    sales: 112000000, // ₹11.20 Cr
    profit: 20160000, // 18.0%
    unitsSold: 134400,
    orders: 67200,
    profitMargin: 18.0,
    returnRate: 14.6, // High return rate in fashion
    cancellationRate: 7.2,
    color: '#ec4899', // pink
    subCategories: ['Ethnic Kurtas', 'Men Casual Shirts', 'Athleisure', 'Footwear', 'Handbags'],
  },
  {
    id: 'cat-home',
    name: 'Home & Kitchen',
    sales: 86500000, // ₹8.65 Cr
    profit: 17300000, // 20.0%
    unitsSold: 69200,
    orders: 43250,
    profitMargin: 20.0,
    returnRate: 6.2,
    cancellationRate: 4.1,
    color: '#f59e0b', // amber
    subCategories: ['Non-stick Cookware', 'Air Fryers', 'Water Bottles', 'Storage Containers', 'Bed Linen'],
  },
  {
    id: 'cat-mobile',
    name: 'Mobile Accessories',
    sales: 52400000, // ₹5.24 Cr
    profit: 13624000, // 26.0% (High Margin)
    unitsSold: 104800,
    orders: 52400,
    profitMargin: 26.0,
    returnRate: 4.2,
    cancellationRate: 3.2,
    color: '#8b5cf6', // purple
    subCategories: ['Fast Chargers', 'Braided Type-C Cables', 'Tempered Glass', 'Car Phone Mounts', 'Cases'],
  },
  {
    id: 'cat-beauty',
    name: 'Beauty & Personal Care',
    sales: 32600000, // ₹3.26 Cr
    profit: 6520000, // 20.0%
    unitsSold: 48900,
    orders: 32600,
    profitMargin: 20.0,
    returnRate: 3.5, // Low return rate
    cancellationRate: 3.8,
    color: '#10b981', // emerald
    subCategories: ['Sunscreen Gel', 'Vitamin C Serum', 'Beard Grooming Kit', 'Hair Serums', 'Fragrances'],
  },
  {
    id: 'cat-books',
    name: 'Books & Stationery',
    sales: 12100000, // ₹1.21 Cr
    profit: 2420000, // 20.0%
    unitsSold: 24200,
    orders: 16130,
    profitMargin: 20.0,
    returnRate: 2.1, // Lowest return rate
    cancellationRate: 2.5,
    color: '#06b6d4', // cyan
    subCategories: ['Self Help & Business', 'Exam Prep Books', 'Notebooks & Planners', 'Art Supplies'],
  },
];

export const TOP_PRODUCTS: ProductItem[] = [
  {
    id: 'p1',
    sku: 'ELEC-ANC-001',
    name: 'boAt Airdopes 141 ANC True Wireless Earbuds (42H Playtime)',
    category: 'Electronics & Gadgets',
    sales: 24500000,
    profit: 5390000,
    profitMargin: 22.0,
    unitsSold: 17500,
    avgSellingPrice: 1400,
    returnRate: 4.8,
    stockStatus: 'In Stock',
    fulfillmentType: 'FBA',
    rating: 4.3,
  },
  {
    id: 'p2',
    sku: 'ELEC-WATCH-002',
    name: 'Noise ColorFit Pulse 2 Max 1.85" Display Smartwatch',
    category: 'Electronics & Gadgets',
    sales: 19800000,
    profit: 4356000,
    profitMargin: 22.0,
    unitsSold: 11000,
    avgSellingPrice: 1800,
    returnRate: 5.4,
    stockStatus: 'In Stock',
    fulfillmentType: 'FBA',
    rating: 4.2,
  },
  {
    id: 'p3',
    sku: 'HOME-FRY-003',
    name: 'Pigeon Healthifry Digital Air Fryer 4.2 Litre (1200W)',
    category: 'Home & Kitchen',
    sales: 16200000,
    profit: 3564000,
    profitMargin: 22.0,
    unitsSold: 5400,
    avgSellingPrice: 3000,
    returnRate: 6.1,
    stockStatus: 'In Stock',
    fulfillmentType: 'FBA',
    rating: 4.4,
  },
  {
    id: 'p4',
    sku: 'MOBI-CHG-004',
    name: 'Ambrane 65W GaN Fast Charger Triple Port (Type-C + USB)',
    category: 'Mobile Accessories',
    sales: 14700000,
    profit: 4116000,
    profitMargin: 28.0,
    unitsSold: 10500,
    avgSellingPrice: 1400,
    returnRate: 3.1,
    stockStatus: 'In Stock',
    fulfillmentType: 'FBA',
    rating: 4.6,
  },
  {
    id: 'p5',
    sku: 'FASH-KURT-005',
    name: 'Biba Women Pure Cotton Straight Floral Kurta & Palazzo Set',
    category: 'Apparel & Fashion',
    sales: 13500000,
    profit: 2295000,
    profitMargin: 17.0,
    unitsSold: 7500,
    avgSellingPrice: 1800,
    returnRate: 15.2, // High return rate
    stockStatus: 'In Stock',
    fulfillmentType: 'Easy Ship',
    rating: 4.0,
  },
  {
    id: 'p6',
    sku: 'ELEC-SPK-006',
    name: 'JBL Go 3 Eco Ultra-Portable Waterproof Bluetooth Speaker',
    category: 'Electronics & Gadgets',
    sales: 12800000,
    profit: 2560000,
    profitMargin: 20.0,
    unitsSold: 4570,
    avgSellingPrice: 2800,
    returnRate: 4.2,
    stockStatus: 'Low Stock',
    fulfillmentType: 'FBA',
    rating: 4.5,
  },
  {
    id: 'p7',
    sku: 'BEAU-SER-007',
    name: 'Minimalist 10% Niacinamide Serum with Zinc for Blemishes 30ml',
    category: 'Beauty & Personal Care',
    sales: 11400000,
    profit: 2736000,
    profitMargin: 24.0,
    unitsSold: 19000,
    avgSellingPrice: 600,
    returnRate: 2.8,
    stockStatus: 'In Stock',
    fulfillmentType: 'FBA',
    rating: 4.7,
  },
  {
    id: 'p8',
    sku: 'HOME-CKW-008',
    name: 'Prestige Omega Deluxe Granite 3-Piece Non-Stick Cookware Set',
    category: 'Home & Kitchen',
    sales: 10200000,
    profit: 1938000,
    profitMargin: 19.0,
    unitsSold: 4250,
    avgSellingPrice: 2400,
    returnRate: 5.9,
    stockStatus: 'In Stock',
    fulfillmentType: 'Easy Ship',
    rating: 4.1,
  },
  {
    id: 'p9',
    sku: 'FASH-SHIRT-009',
    name: 'Dennis Lingo Men Slim Fit Casual Cotton Checkered Shirt',
    category: 'Apparel & Fashion',
    sales: 9400000,
    profit: 1410000,
    profitMargin: 15.0,
    unitsSold: 13420,
    avgSellingPrice: 700,
    returnRate: 16.4, // High return rate
    stockStatus: 'Reorder',
    fulfillmentType: 'Seller Fulfilled',
    rating: 3.9,
  },
  {
    id: 'p10',
    sku: 'MOBI-PWR-010',
    name: 'Mi 20000mAh 18W Fast Charging Power Bank 3i (Dual Input)',
    category: 'Mobile Accessories',
    sales: 8900000,
    profit: 2314000,
    profitMargin: 26.0,
    unitsSold: 4940,
    avgSellingPrice: 1800,
    returnRate: 3.8,
    stockStatus: 'In Stock',
    fulfillmentType: 'FBA',
    rating: 4.4,
  },
];

export const ORDER_STATUS_SUMMARY: OrderStatusMetrics = {
  totalOrders: 288475,
  deliveredOrders: 235680,
  shippedOrders: 16730,
  returnedOrders: 21635,
  cancelledOrders: 14430,
  returnRate: 7.5,
  cancellationRate: 5.0,
  deliveredRate: 81.7,
  estimatedReturnRevenueLoss: 38943000, // ~₹3.89 Cr in returned GMV
  estimatedCancellationRevenueLoss: 25974000, // ~₹2.60 Cr in cancelled GMV
  reverseLogisticsCost: 4327000, // ~₹43.2 L in pure return courier / packaging costs
};

export const PAYMENT_METHODS: PaymentMethodData[] = [
  {
    method: 'UPI',
    label: 'UPI (PhonePe, GPay, Paytm)',
    sales: 211200000, // ₹21.12 Cr (44%)
    profit: 46464000, // 22% margin
    orders: 135583,
    profitMargin: 22.0,
    rtoRate: 2.4, // Very low RTO!
    sharePercentage: 44.0,
    iconName: 'Smartphone',
  },
  {
    method: 'Credit Card',
    label: 'Credit Cards (Visa, MC, RuPay)',
    sales: 110400000, // ₹11.04 Cr (23%)
    profit: 23184000, // 21% margin
    orders: 49040,
    profitMargin: 21.0,
    rtoRate: 2.1,
    sharePercentage: 23.0,
    iconName: 'CreditCard',
  },
  {
    method: 'COD',
    label: 'Cash on Delivery (COD)',
    sales: 72000000, // ₹7.20 Cr (15%)
    profit: 7920000, // 11% margin (eroded by RTO)
    orders: 46156,
    profitMargin: 11.0,
    rtoRate: 17.8, // Alarmingly high RTO
    sharePercentage: 15.0,
    iconName: 'Banknote',
  },
  {
    method: 'Debit Card',
    label: 'Debit Cards & Net Banking',
    sales: 48000000, // ₹4.80 Cr (10%)
    profit: 9600000, // 20% margin
    orders: 31732,
    profitMargin: 20.0,
    rtoRate: 3.2,
    sharePercentage: 10.0,
    iconName: 'Building2',
  },
  {
    method: 'Amazon Pay',
    label: 'Amazon Pay Balance & UPI',
    sales: 24000000, // ₹2.40 Cr (5%)
    profit: 5280000, // 22% margin
    orders: 17308,
    profitMargin: 22.0,
    rtoRate: 1.8, // Lowest RTO
    sharePercentage: 5.0,
    iconName: 'Zap',
  },
  {
    method: 'EMI',
    label: 'No-Cost EMI & Pay Later',
    sales: 14400000, // ₹1.44 Cr (3%)
    profit: 2880000, // 20% margin
    orders: 8656,
    profitMargin: 20.0,
    rtoRate: 2.6,
    sharePercentage: 3.0,
    iconName: 'Clock',
  },
];

export const FULFILLMENT_METHODS: FulfillmentMethodData[] = [
  {
    method: 'FBA',
    name: 'Fulfilled by Amazon (FBA)',
    description: 'Stored in Amazon FCs, prime guaranteed 1-2 day delivery with Amazon customer service',
    sales: 297600000, // ₹29.76 Cr (62%)
    profit: 62496000, // 21% margin
    orders: 178854,
    unitsSold: 286166,
    profitMargin: 21.0,
    avgDeliveryDays: 1.6,
    onTimeDeliveryRate: 98.7,
    sharePercentage: 62.0,
  },
  {
    method: 'Easy Ship',
    name: 'Amazon Easy Ship',
    description: 'Seller packed, Amazon logistics pickup and door-to-door delivery across India',
    sales: 124800000, // ₹12.48 Cr (26%)
    profit: 22464000, // 18% margin
    orders: 75003,
    unitsSold: 120005,
    profitMargin: 18.0,
    avgDeliveryDays: 3.4,
    onTimeDeliveryRate: 93.2,
    sharePercentage: 26.0,
  },
  {
    method: 'Seller Fulfilled',
    name: 'Seller Fulfilled / FBM',
    description: 'Dispatched via third-party couriers (Delhivery, Bluedart, DTDC) directly from warehouse',
    sales: 57600000, // ₹5.76 Cr (12%)
    profit: 8064000, // 14% margin
    orders: 34618,
    unitsSold: 55389,
    profitMargin: 14.0,
    avgDeliveryDays: 5.2,
    onTimeDeliveryRate: 86.4,
    sharePercentage: 12.0,
  },
];

export const STATE_PERFORMANCE: StatePerformance[] = [
  {
    state: 'Maharashtra',
    stateCode: 'MH',
    region: 'West',
    sales: 104500000, // ₹10.45 Cr
    profit: 21945000,
    orders: 62700,
    unitsSold: 100320,
    profitMargin: 21.0,
    returnRate: 6.2,
    topCategory: 'Electronics & Gadgets',
  },
  {
    state: 'Karnataka',
    stateCode: 'KA',
    region: 'South',
    sales: 81500000, // ₹8.15 Cr
    profit: 17930000,
    orders: 48900,
    unitsSold: 78240,
    profitMargin: 22.0,
    returnRate: 5.4,
    topCategory: 'Electronics & Gadgets',
  },
  {
    state: 'Delhi NCR',
    stateCode: 'DL',
    region: 'North',
    sales: 73500000, // ₹7.35 Cr
    profit: 14700000,
    orders: 44100,
    unitsSold: 70560,
    profitMargin: 20.0,
    returnRate: 7.8,
    topCategory: 'Apparel & Fashion',
  },
  {
    state: 'Tamil Nadu',
    stateCode: 'TN',
    region: 'South',
    sales: 52800000, // ₹5.28 Cr
    profit: 11088000,
    orders: 31680,
    unitsSold: 50688,
    profitMargin: 21.0,
    returnRate: 5.9,
    topCategory: 'Home & Kitchen',
  },
  {
    state: 'Telangana',
    stateCode: 'TS',
    region: 'South',
    sales: 44200000, // ₹4.42 Cr
    profit: 9724000,
    orders: 26520,
    unitsSold: 42432,
    profitMargin: 22.0,
    returnRate: 6.1,
    topCategory: 'Electronics & Gadgets',
  },
  {
    state: 'Gujarat',
    stateCode: 'GJ',
    region: 'West',
    sales: 38600000, // ₹3.86 Cr
    profit: 7720000,
    orders: 23160,
    unitsSold: 37056,
    profitMargin: 20.0,
    returnRate: 6.5,
    topCategory: 'Mobile Accessories',
  },
  {
    state: 'Uttar Pradesh',
    stateCode: 'UP',
    region: 'North',
    sales: 34500000, // ₹3.45 Cr
    profit: 5520000,
    orders: 20700,
    unitsSold: 33120,
    profitMargin: 16.0,
    returnRate: 11.2, // High return rate in UP (heavy COD)
    topCategory: 'Apparel & Fashion',
  },
  {
    state: 'West Bengal',
    stateCode: 'WB',
    region: 'East',
    sales: 21400000, // ₹2.14 Cr
    profit: 4066000,
    orders: 12840,
    unitsSold: 20544,
    profitMargin: 19.0,
    returnRate: 8.4,
    topCategory: 'Books & Stationery',
  },
  {
    state: 'Rajasthan',
    stateCode: 'RJ',
    region: 'North',
    sales: 15200000, // ₹1.52 Cr
    profit: 2736000,
    orders: 9120,
    unitsSold: 14592,
    profitMargin: 18.0,
    returnRate: 9.1,
    topCategory: 'Apparel & Fashion',
  },
  {
    state: 'Kerala',
    stateCode: 'KL',
    region: 'South',
    sales: 13800000, // ₹1.38 Cr
    profit: 2898000,
    orders: 8280,
    unitsSold: 13248,
    profitMargin: 21.0,
    returnRate: 5.1,
    topCategory: 'Beauty & Personal Care',
  },
];

export const EXECUTIVE_INSIGHTS: ExecutiveInsight[] = [
  {
    type: 'positive',
    title: 'Strong Festive Momentum & Margin Resilience',
    description: 'Total revenue touched ₹48.00 Cr with a healthy overall net profit margin of 19.85% (₹9.53 Cr). The Great Indian Festival (Oct) and Diwali (Nov) generated 26% of annual volume with peak profitability.',
    metric: '+23.4% YoY',
    actionableStep: 'Pre-book additional FBA warehouse space in Bhiwandi (MH) and Attibele (KA) 45 days prior to Prime Day.',
  },
  {
    type: 'positive',
    title: 'FBA & UPI Channels Drive 70%+ of High-Margin Profit',
    description: 'UPI is now our dominant payment mode (44% share) with an exceptional 97.6% delivery success. FBA orders deliver in 1.6 days on average with 98.7% on-time rate and 21% net margin.',
    metric: '44% UPI Share',
    actionableStep: 'Continue promoting Amazon Pay UPI cashbacks to convert remaining COD users to prepaid.',
  },
  {
    type: 'critical',
    title: 'COD Returns in Apparel Are Bleeding ₹2.4 Cr Annually',
    description: 'Cash on Delivery (COD) orders suffer an alarming 17.8% Return-to-Origin (RTO) rate, heavily concentrated in Apparel & Fashion (14.6% category return). Return logistics and packaging costs total ₹43.2 Lakhs.',
    metric: '17.8% COD RTO',
    actionableStep: 'Mandate ₹49 advance deposit or OTP verification for COD orders above ₹1,500 in Tier-2/3 pincodes.',
  },
  {
    type: 'warning',
    title: 'Seller-Fulfilled (FBM) Slower Delivery & Margin Drag',
    description: 'Seller-fulfilled orders take 5.2 days on average, yielding only 14.0% margin compared to 21.0% in FBA, and have a 13.6% lower on-time delivery rate (86.4%).',
    metric: '5.2 Days Delivery',
    actionableStep: 'Transition top 20 high-velocity seller-fulfilled SKUs into FBA or Easy Ship tier-1 hubs.',
  },
];

export const MANOJ_MEMO = {
  to: 'Ravi (General Manager / Operations Lead)',
  from: 'Manoj (Amazon Operations & Analytics Lead, Sapphire IQ)',
  date: 'March 2024 / FY24 Executive Review',
  subject: 'Executive Performance Briefing: Amazon India Operations & Profitability',
  status: 'Ready for Management Review',
  executiveSummary: `Hi Ravi,

I have compiled our comprehensive business performance report across all 4 operational pillars for your review. This dashboard is designed with simple visual indicators, clear financial metrics, and non-technical explanations so you can present it directly to executive leadership or use it for operational planning.

Key Highlights for Your Quick Review:
1. Top-Line Growth: We closed FY24 at ₹48.00 Cr Gross Sales with ₹9.53 Cr in net profit (19.85% net margin). Average order value stood at ₹1,664.
2. Best Driving Categories: Electronics & Gadgets led with ₹18.45 Cr, followed by Fashion at ₹11.20 Cr. Mobile Accessories was our most profitable category at 26.0% margin.
3. Revenue Protection Priority: Returns and cancellations cost us an estimated ₹6.49 Cr in lost gross volume and ₹43.2 Lakhs in reverse logistics courier fees. COD return rate (17.8%) is our single biggest profit leak.
4. Channel Efficiency: FBA continues to outperform third-party courier shipping by 7% higher margins and 3.6 days faster doorstep arrival.

Please use the interactive tabs below to examine each slide requirement or switch to Presentation Mode for your management meetings.`,
};
